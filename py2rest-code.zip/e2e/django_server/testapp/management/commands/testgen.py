import os
import sys

from django.core.management import BaseCommand

from django.conf import settings

main_module_dir = os.path.dirname(os.path.dirname(settings.BASE_DIR))
sys.path.insert(0, main_module_dir)

from py2rest.argresolvers import DjangoArgResolver
from py2rest.engines.ts.fetchapi import FetchApiEngine
from py2rest.engines.openapi.openapi import OpenAPIEngine
from py2rest.engines.python.py_requests import PythonRequestsEngine
from py2rest.engines.ts.angular import AngularEngine
from py2rest.py2rest_gen import Py2Rest


class Command(BaseCommand):

    def handle(self, *args, **options):
        python_path = os.path.join(os.path.dirname(settings.BASE_DIR), 'python', 'gen')
        angular_path = os.path.join(os.path.dirname(settings.BASE_DIR), 'testangular', 'src', 'app', 'gen')
        fetch_path = os.path.join(os.path.dirname(settings.BASE_DIR), 'testangular', 'src', 'assets', 'gen')
        openapi_path = os.path.join(os.path.dirname(settings.BASE_DIR), 'openapi', 'gen')
        py2re = Py2Rest('http://127.0.0.1:8000', [AngularEngine(generation_path=angular_path),
                                                  FetchApiEngine(generation_path=fetch_path),
                                                  PythonRequestsEngine(generation_path=python_path),
                                                  OpenAPIEngine(generation_path=openapi_path)],
                        DjangoArgResolver())
        py2re.read_decorated_endpoints()
        py2re.generate()
