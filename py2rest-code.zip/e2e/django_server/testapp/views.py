import datetime
import decimal
import json
import os
import sys

from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt

main_module_dir = os.path.dirname(os.path.dirname(settings.BASE_DIR))
sys.path.insert(0, main_module_dir)

from py2rest import http_method
from py2rest.api.fields import JSONObject, CharField, BooleanField, IntegerField, AnyField, FormData, FileUploadField, \
    ListField, DateField, DateTimeField, DecimalField
from py2rest.api.parameter import Parameter
from py2rest.api_endpoint import api_endpoint


@api_endpoint(method=http_method.GET,
              group_name='api', name='test_hello_world', return_type=CharField())
def test_hello_world(request):
    return HttpResponse("Hello test world!")


@api_endpoint(method=http_method.GET,
              group_name='api', name='test_hello_world_with_url_param', return_type=CharField())
def test_hello_world_with_url_param(request, test_url_param):
    return HttpResponse("Hello test_url_param=" + str(test_url_param))


@api_endpoint(method=http_method.GET,
              query_params=[Parameter('test-query-param', int)],
              group_name='api', name='test_hello_world_with_param', return_type=CharField())
def test_hello_world_with_param(request):
    return HttpResponse("Hello test-query-param=" + request.GET.get('test-query-param', ''))


@api_endpoint(method=http_method.GET,
              headers=[Parameter('test-header', int)],
              group_name='api', name='test_hello_world_with_header', return_type=CharField())
def test_hello_world_with_header(request):
    return HttpResponse("Hello test-header=" + request.META.get('HTTP_TEST_HEADER', ''))

    # noinspection PyUnreachableCode

class TestJsonReponseJSON(JSONObject):
    testInt = IntegerField()
    testBool = BooleanField()
    testString = CharField()
    testDate = DateField()
    testDateTime = DateTimeField()
    testDecimal = DecimalField()


@api_endpoint(method=http_method.GET,
              group_name='api', name='test_json_response',
              return_type=TestJsonReponseJSON())
@csrf_exempt
def test_json_response(request):
    return JsonResponse(
        {
            'testInt': 1,
            'testBool': True,
            'testString': 'testString',
            'testDate': datetime.date(2000, 1, 1),
            'testDateTime': datetime.datetime(2000, 1, 1, 12, 12, 12, 500000),
            'testDecimal': decimal.Decimal('12.345')
        }
    )


@api_endpoint(method=http_method.POST,
              group_name='api', name='test_json_echo',
              body=AnyField(),
              return_type=AnyField())
@csrf_exempt
def test_json_echo(request):
    return JsonResponse(json.loads(request.body))


class JsonEchoResponse(JSONObject):
    test_url_param1 = CharField()
    test_url_param2 = IntegerField()
    test_query_param1 = CharField()
    test_query_param2 = CharField()
    test_header_1 = CharField()
    test_header_2 = CharField()
    test_body = AnyField()


@api_endpoint(query_params=[Parameter('test-query-param-1', int), Parameter('test-query-param-2', int)],
              headers=[Parameter('test-header-1', bool), Parameter('test-header-2', str)],
              method=http_method.POST,
              group_name='api',
              name='test_json_echo_with_params_url_query_header',
              body=AnyField(),
              return_type=JsonEchoResponse())
@csrf_exempt
def test_json_echo_with_params_url_query_header(request, test_url_param1, test_url_param2):
    return JsonResponse(
        {
            'test_url_param1': test_url_param1,
            'test_url_param2': test_url_param2,
            'test_query_param1': request.GET.get('test-query-param-1', ''),
            'test_query_param2': request.GET.get('test-query-param-2', ''),
            'test_header_1': request.META.get('HTTP_TEST_HEADER_1', ''),
            'test_header_2': request.META.get('HTTP_TEST_HEADER_2', ''),
            'test_body': json.loads(request.body)
        }
    )


class TestFormData(FormData):
    test_int = IntegerField()
    test_str = CharField()


class TestJSON(JSONObject):
    test_int = IntegerField()
    test_str = CharField()


class TestFormDataReturn(JSONObject):
    test_url_param1 = CharField()
    test_url_param2 = IntegerField()
    test_query_param1 = CharField()
    test_query_param2 = CharField()
    test_header_1 = CharField()
    test_header_2 = CharField()
    test_form_data = TestJSON()


@api_endpoint(query_params=[Parameter('test-query-param-1', int), Parameter('test-query-param-2', int)],
              headers=[Parameter('test-header-1', bool), Parameter('test-header-2', str)],
              method=http_method.POST,
              group_name='api',
              name='test_form_data_with_params_url_query_header',
              body=TestFormData(),
              return_type=TestFormDataReturn())
@csrf_exempt
def test_form_data_with_params_url_query_header(request, test_url_param1, test_url_param2):
    return JsonResponse(
        {
            'test_url_param1': test_url_param1,
            'test_url_param2': test_url_param2,
            'test_query_param1': request.GET.get('test-query-param-1', ''),
            'test_query_param2': request.GET.get('test-query-param-2', ''),
            'test_header_1': request.META.get('HTTP_TEST_HEADER_1', ''),
            'test_header_2': request.META.get('HTTP_TEST_HEADER_2', ''),
            'test_form_data': {'test_int': int(request.POST['test_int']), 'test_str': request.POST['test_str']}
        }
    )


class TestFormDataWithFile(FormData):
    test_int = IntegerField()
    test_str = CharField()
    test_file_1 = FileUploadField()
    test_file_2 = FileUploadField()


class TestFormDataWithFileReturnType(JSONObject):
    test_url_param1 = CharField()
    test_url_param2 = IntegerField()
    test_query_param1 = CharField()
    test_query_param2 = CharField()
    test_header_1 = CharField()
    test_header_2 = CharField()
    test_form_data = TestJSON()
    test_file_1 = CharField()
    test_file_2 = CharField()


@api_endpoint(query_params=[Parameter('test-query-param-1', int), Parameter('test-query-param-2', int)],
              headers=[Parameter('test-header-1', bool), Parameter('test-header-2', str)],
              method=http_method.POST,
              group_name='api',
              name='test_form_data_with_params_url_query_header_files',
              body=TestFormDataWithFile(),
              return_type=TestFormDataWithFileReturnType())
@csrf_exempt
def test_form_data_with_params_url_query_header_files(request, test_url_param1, test_url_param2):
    return JsonResponse(
        {
            'test_url_param1': test_url_param1,
            'test_url_param2': test_url_param2,
            'test_query_param1': request.GET.get('test-query-param-1', ''),
            'test_query_param2': request.GET.get('test-query-param-2', ''),
            'test_header_1': request.META.get('HTTP_TEST_HEADER_1', ''),
            'test_header_2': request.META.get('HTTP_TEST_HEADER_2', ''),
            'test_form_data': {'test_int': int(request.POST['test_int']), 'test_str': request.POST['test_str']},
            'test_file_1': request.FILES['test_file_1'].read().decode('utf-8'),
            'test_file_2': request.FILES['test_file_2'].read().decode('utf-8')
        }
    )
