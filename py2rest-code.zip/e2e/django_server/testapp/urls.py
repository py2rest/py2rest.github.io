from django.urls import path

from testapp import views

urlpatterns = [
    path('test_hello_world', views.test_hello_world),
    path('test_hello_world_with_url_param/<int:test_url_param>', views.test_hello_world_with_url_param),
    path('test_hello_world_with_param', views.test_hello_world_with_param),
    path('test_hello_world_with_header', views.test_hello_world_with_header),
    path('test_json_response', views.test_json_response),
    path('test_json_echo', views.test_json_echo),
    path('test_json_echo_with_params_url_query_header/<str:test_url_param1>/<int:test_url_param2>', views.test_json_echo_with_params_url_query_header),
    path('test_form_data_with_params_url_query_header/<str:test_url_param1>/<int:test_url_param2>', views.test_form_data_with_params_url_query_header),
    path('test_form_data_with_params_url_query_header_files/<str:test_url_param1>/<int:test_url_param2>', views.test_form_data_with_params_url_query_header_files)
]
