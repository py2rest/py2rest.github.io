def x():

    from django.db import models

    class Book(models.Model):
        title = models.CharField()
        abstract = models.CharField()
        sales = models.IntegerField()
        content = models.TextField()



    TestJsonReponseJSON