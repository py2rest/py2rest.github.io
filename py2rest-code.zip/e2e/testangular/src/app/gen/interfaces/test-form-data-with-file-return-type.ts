import { TestJSON } from './test-json';

export interface TestFormDataWithFileReturnType {
  test_url_param1?: string;
  test_url_param2?: number;
  test_query_param1?: string;
  test_query_param2?: string;
  test_header_1?: string;
  test_header_2?: string;
  test_form_data?: TestJSON;
  test_file_1?: string;
  test_file_2?: string;
}
