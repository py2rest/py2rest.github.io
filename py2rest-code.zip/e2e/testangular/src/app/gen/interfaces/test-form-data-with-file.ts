
export interface TestFormDataWithFile {
  test_int?: number;
  test_str?: string;
  test_file_1?: File;
  test_file_2?: File;
}
