
export interface TestJSON {
  test_int?: number;
  test_str?: string;
}
