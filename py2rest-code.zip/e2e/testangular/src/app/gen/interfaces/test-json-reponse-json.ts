
export interface TestJsonReponseJSON {
  testInt?: number;
  testBool?: boolean;
  testString?: string;
  testDate?: Date;
  testDateTime?: Date;
  testDecimal?: string;
}
