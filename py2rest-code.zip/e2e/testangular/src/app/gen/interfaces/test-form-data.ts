
export interface TestFormData {
  test_int?: number;
  test_str?: string;
}
