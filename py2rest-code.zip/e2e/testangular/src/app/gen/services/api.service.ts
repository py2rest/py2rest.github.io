import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";

import * as deserializers from "../deserializers";

import { TestJsonReponseJSON } from '../interfaces/test-json-reponse-json';
import { TestFormDataReturn } from '../interfaces/test-form-data-return';
import { TestFormDataWithFile } from '../interfaces/test-form-data-with-file';
import { JsonEchoResponse } from '../interfaces/json-echo-response';
import { TestFormDataWithFileReturnType } from '../interfaces/test-form-data-with-file-return-type';
import { TestFormData } from '../interfaces/test-form-data';

@Injectable()
export class ApiService {
  constructor(private http: HttpClient) { }

  test_hello_world(): Observable<string> {

    return this.http.get(`http://127.0.0.1:8000/test/test_hello_world`,
        { responseType: 'text' });
  }
  /**
   * accepts url params:
   * test_url_param - required: False, 
   */
  test_hello_world_with_url_param(test_url_param: number): Observable<string> {

    return this.http.get(`http://127.0.0.1:8000/test/test_hello_world_with_url_param/${test_url_param}`,
        { responseType: 'text' });
  }
  /**
   * accepts query params:
   * test_query_param - required: False, 
   */
  test_hello_world_with_param(test_query_param: number): Observable<string> {
    let params = new HttpParams();

    if (test_query_param !== null && test_query_param !== undefined) {
      params = params.set('test-query-param', test_query_param.toString());
    }


    return this.http.get(`http://127.0.0.1:8000/test/test_hello_world_with_param`,
        { responseType: 'text', params: params });
  }
  /**
   * accepts headers:
   * test_header - required: False, 
   */
  test_hello_world_with_header(test_header: number): Observable<string> {
    let headers = new HttpHeaders();

    if (test_header !== null && test_header !== undefined) {
      headers = headers.set('test-header', test_header.toString());
    }

    return this.http.get(`http://127.0.0.1:8000/test/test_hello_world_with_header`,
        { responseType: 'text', headers: headers });
  }
  test_json_response(): Observable<TestJsonReponseJSON> {

    return this.http.get(`http://127.0.0.1:8000/test/test_json_response`,
        { responseType: 'text' }).pipe(map(data => deserializers.deserializeTestJsonReponseJSON(data)));  }
  test_json_echo(body: any): Observable<any> {

    return this.http.post(`http://127.0.0.1:8000/test/test_json_echo`, body,
        { responseType: 'json' });
  }
  /**
   * accepts query params:
   * test_query_param_1 - required: False, 
   * test_query_param_2 - required: False, 
   * accepts url params:
   * test_url_param1 - required: False, 
   * test_url_param2 - required: False, 
   * accepts headers:
   * test_header_1 - required: False, 
   * test_header_2 - required: False, 
   */
  test_json_echo_with_params_url_query_header(body: any, test_url_param1: string, test_url_param2: number, test_query_param_1: number, test_query_param_2: number, test_header_1: boolean, test_header_2: string): Observable<JsonEchoResponse> {
    let params = new HttpParams();

    if (test_query_param_1 !== null && test_query_param_1 !== undefined) {
      params = params.set('test-query-param-1', test_query_param_1.toString());
    }
    if (test_query_param_2 !== null && test_query_param_2 !== undefined) {
      params = params.set('test-query-param-2', test_query_param_2.toString());
    }

    let headers = new HttpHeaders();

    if (test_header_1 !== null && test_header_1 !== undefined) {
      headers = headers.set('test-header-1', test_header_1.toString());
    }
    if (test_header_2 !== null && test_header_2 !== undefined) {
      headers = headers.set('test-header-2', test_header_2);
    }

    return this.http.post(`http://127.0.0.1:8000/test/test_json_echo_with_params_url_query_header/${test_url_param1}/${test_url_param2}`, body,
        { responseType: 'text', headers: headers, params: params }).pipe(map(data => deserializers.deserializeJsonEchoResponse(data)));  }
  /**
   * accepts query params:
   * test_query_param_1 - required: False, 
   * test_query_param_2 - required: False, 
   * accepts url params:
   * test_url_param1 - required: False, 
   * test_url_param2 - required: False, 
   * accepts headers:
   * test_header_1 - required: False, 
   * test_header_2 - required: False, 
   */
  test_form_data_with_params_url_query_header(body: TestFormData, test_url_param1: string, test_url_param2: number, test_query_param_1: number, test_query_param_2: number, test_header_1: boolean, test_header_2: string): Observable<TestFormDataReturn> {
    let params = new HttpParams();

    if (test_query_param_1 !== null && test_query_param_1 !== undefined) {
      params = params.set('test-query-param-1', test_query_param_1.toString());
    }
    if (test_query_param_2 !== null && test_query_param_2 !== undefined) {
      params = params.set('test-query-param-2', test_query_param_2.toString());
    }

    let headers = new HttpHeaders();

    if (test_header_1 !== null && test_header_1 !== undefined) {
      headers = headers.set('test-header-1', test_header_1.toString());
    }
    if (test_header_2 !== null && test_header_2 !== undefined) {
      headers = headers.set('test-header-2', test_header_2);
    }

    let formData = new FormData();
    formData.append('test_int', body.test_int.toString());
    formData.append('test_str', body.test_str);
    return this.http.post(`http://127.0.0.1:8000/test/test_form_data_with_params_url_query_header/${test_url_param1}/${test_url_param2}`, formData,
        { responseType: 'text', headers: headers, params: params }).pipe(map(data => deserializers.deserializeTestFormDataReturn(data)));  }
  /**
   * accepts query params:
   * test_query_param_1 - required: False, 
   * test_query_param_2 - required: False, 
   * accepts url params:
   * test_url_param1 - required: False, 
   * test_url_param2 - required: False, 
   * accepts headers:
   * test_header_1 - required: False, 
   * test_header_2 - required: False, 
   */
  test_form_data_with_params_url_query_header_files(body: TestFormDataWithFile, test_url_param1: string, test_url_param2: number, test_query_param_1: number, test_query_param_2: number, test_header_1: boolean, test_header_2: string): Observable<TestFormDataWithFileReturnType> {
    let params = new HttpParams();

    if (test_query_param_1 !== null && test_query_param_1 !== undefined) {
      params = params.set('test-query-param-1', test_query_param_1.toString());
    }
    if (test_query_param_2 !== null && test_query_param_2 !== undefined) {
      params = params.set('test-query-param-2', test_query_param_2.toString());
    }

    let headers = new HttpHeaders();

    if (test_header_1 !== null && test_header_1 !== undefined) {
      headers = headers.set('test-header-1', test_header_1.toString());
    }
    if (test_header_2 !== null && test_header_2 !== undefined) {
      headers = headers.set('test-header-2', test_header_2);
    }

    let formData = new FormData();
    formData.append('test_int', body.test_int.toString());
    formData.append('test_str', body.test_str);
    formData.append('test_file_1', body.test_file_1);
    formData.append('test_file_2', body.test_file_2);
    return this.http.post(`http://127.0.0.1:8000/test/test_form_data_with_params_url_query_header_files/${test_url_param1}/${test_url_param2}`, formData,
        { responseType: 'text', headers: headers, params: params }).pipe(map(data => deserializers.deserializeTestFormDataWithFileReturnType(data)));  }
}