export function deserializeTestJsonReponseJSON(response_body) {
  var obj = JSON.parse(response_body);
  if (obj.testDate) {
    obj.testDate = new Date(obj.testDate);
  }
  if (obj.testDateTime) {
    obj.testDateTime = new Date(obj.testDateTime);
  }

  return obj;
}

export function deserializeJsonEchoResponse(response_body) {
  var obj = JSON.parse(response_body);
  
  return obj;
}

export function deserializeTestFormDataReturn(response_body) {
  var obj = JSON.parse(response_body);
  
  return obj;
}

export function deserializeTestJSON(response_body) {
  var obj = JSON.parse(response_body);
  
  return obj;
}

export function deserializeTestFormData(response_body) {
  var obj = JSON.parse(response_body);
  
  return obj;
}

export function deserializeTestFormDataWithFileReturnType(response_body) {
  var obj = JSON.parse(response_body);
  
  return obj;
}

export function deserializeTestFormDataWithFile(response_body) {
  var obj = JSON.parse(response_body);
  
  return obj;
}

