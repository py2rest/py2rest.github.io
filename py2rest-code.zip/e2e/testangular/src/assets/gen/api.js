/**
 * returns object:
 * string
 */
function test_hello_world() {
  var _url = `http://127.0.0.1:8000/test/test_hello_world`;


  return fetch(_url, {
    method: 'get',
  });
}


/**
 * accepts url params:
 * test_url_param - required: False, 
 * returns object:
 * string
 */
function test_hello_world_with_url_param(test_url_param) {
  var _url = `http://127.0.0.1:8000/test/test_hello_world_with_url_param/${test_url_param}`;


  return fetch(_url, {
    method: 'get',
  });
}


/**
 * accepts query params:
 * test_query_param - required: False, 
 * returns object:
 * string
 */
function test_hello_world_with_param(test_query_param) {
  var _params = new URLSearchParams();
  if (test_query_param !== null && test_query_param !== undefined) {
    _params.append('test-query-param', test_query_param.toString());
  }
  var _url = `http://127.0.0.1:8000/test/test_hello_world_with_param?` + _params.toString();


  return fetch(_url, {
    method: 'get',
  });
}


/**
 * accepts headers:
 * test_header - required: False, 
 * returns object:
 * string
 */
function test_hello_world_with_header(test_header) {
  var _url = `http://127.0.0.1:8000/test/test_hello_world_with_header`;
  var _headers = {};
  if (test_header !== null && test_header !== undefined) {
    _headers['test-header'] = test_header.toString();
  }


  return fetch(_url, {
    method: 'get',
    headers: _headers,
  });
}


/**
 * returns object:
 * {
 *    testInt: number
 *    testBool: boolean
 *    testString: string
 *    testDate: Date
 *    testDateTime: Date
 *    testDecimal: string
 *  }
 */
function test_json_response() {
  var _url = `http://127.0.0.1:8000/test/test_json_response`;


  return fetch(_url, {
    method: 'get',
  });
}


/**
 * accepts body:
 * any
 * returns object:
 * any
 */
function test_json_echo(body) {
  var _url = `http://127.0.0.1:8000/test/test_json_echo`;


  return fetch(_url, {
    method: 'post',
    body: JSON.stringify(body)
  });
}


/**
 * accepts query params:
 * test_query_param_1 - required: False, 
 * test_query_param_2 - required: False, 
 * accepts url params:
 * test_url_param1 - required: False, 
 * test_url_param2 - required: False, 
 * accepts headers:
 * test_header_1 - required: False, 
 * test_header_2 - required: False, 
 * accepts body:
 * any
 * returns object:
 * {
 *    test_url_param1: string
 *    test_url_param2: number
 *    test_query_param1: string
 *    test_query_param2: string
 *    test_header_1: string
 *    test_header_2: string
 *    test_body: any
 *  }
 */
function test_json_echo_with_params_url_query_header(body, test_url_param1, test_url_param2, test_query_param_1, test_query_param_2, test_header_1, test_header_2) {
  var _params = new URLSearchParams();
  if (test_query_param_1 !== null && test_query_param_1 !== undefined) {
    _params.append('test-query-param-1', test_query_param_1.toString());
  }
  if (test_query_param_2 !== null && test_query_param_2 !== undefined) {
    _params.append('test-query-param-2', test_query_param_2.toString());
  }
  var _url = `http://127.0.0.1:8000/test/test_json_echo_with_params_url_query_header/${test_url_param1}/${test_url_param2}?` + _params.toString();
  var _headers = {};
  if (test_header_1 !== null && test_header_1 !== undefined) {
    _headers['test-header-1'] = test_header_1.toString();
  }
  if (test_header_2 !== null && test_header_2 !== undefined) {
    _headers['test-header-2'] = test_header_2;
  }


  return fetch(_url, {
    method: 'post',
    headers: _headers,
    body: JSON.stringify(body)
  });
}


/**
 * accepts query params:
 * test_query_param_1 - required: False, 
 * test_query_param_2 - required: False, 
 * accepts url params:
 * test_url_param1 - required: False, 
 * test_url_param2 - required: False, 
 * accepts headers:
 * test_header_1 - required: False, 
 * test_header_2 - required: False, 
 * accepts body:
 * {
 *    test_int: number
 *    test_str: string
 *  }
 * returns object:
 * {
 *    test_url_param1: string
 *    test_url_param2: number
 *    test_query_param1: string
 *    test_query_param2: string
 *    test_header_1: string
 *    test_header_2: string
 *    test_form_data: {
 *      test_int: number
 *      test_str: string
 *    }
 *  }
 */
function test_form_data_with_params_url_query_header(body, test_url_param1, test_url_param2, test_query_param_1, test_query_param_2, test_header_1, test_header_2) {
  var _params = new URLSearchParams();
  if (test_query_param_1 !== null && test_query_param_1 !== undefined) {
    _params.append('test-query-param-1', test_query_param_1.toString());
  }
  if (test_query_param_2 !== null && test_query_param_2 !== undefined) {
    _params.append('test-query-param-2', test_query_param_2.toString());
  }
  var _url = `http://127.0.0.1:8000/test/test_form_data_with_params_url_query_header/${test_url_param1}/${test_url_param2}?` + _params.toString();
  var _headers = {};
  if (test_header_1 !== null && test_header_1 !== undefined) {
    _headers['test-header-1'] = test_header_1.toString();
  }
  if (test_header_2 !== null && test_header_2 !== undefined) {
    _headers['test-header-2'] = test_header_2;
  }

  let formData = new FormData();
  formData.append('test_int', body.test_int.toString());
  formData.append('test_str', body.test_str);

  return fetch(_url, {
    method: 'post',
    headers: _headers,
    body: formData
  });
}


/**
 * accepts query params:
 * test_query_param_1 - required: False, 
 * test_query_param_2 - required: False, 
 * accepts url params:
 * test_url_param1 - required: False, 
 * test_url_param2 - required: False, 
 * accepts headers:
 * test_header_1 - required: False, 
 * test_header_2 - required: False, 
 * accepts body:
 * {
 *    test_int: number
 *    test_str: string
 *    test_file_1: File
 *    test_file_2: File
 *  }
 * returns object:
 * {
 *    test_url_param1: string
 *    test_url_param2: number
 *    test_query_param1: string
 *    test_query_param2: string
 *    test_header_1: string
 *    test_header_2: string
 *    test_form_data: {
 *      test_int: number
 *      test_str: string
 *    }
 *    test_file_1: string
 *    test_file_2: string
 *  }
 */
function test_form_data_with_params_url_query_header_files(body, test_url_param1, test_url_param2, test_query_param_1, test_query_param_2, test_header_1, test_header_2) {
  var _params = new URLSearchParams();
  if (test_query_param_1 !== null && test_query_param_1 !== undefined) {
    _params.append('test-query-param-1', test_query_param_1.toString());
  }
  if (test_query_param_2 !== null && test_query_param_2 !== undefined) {
    _params.append('test-query-param-2', test_query_param_2.toString());
  }
  var _url = `http://127.0.0.1:8000/test/test_form_data_with_params_url_query_header_files/${test_url_param1}/${test_url_param2}?` + _params.toString();
  var _headers = {};
  if (test_header_1 !== null && test_header_1 !== undefined) {
    _headers['test-header-1'] = test_header_1.toString();
  }
  if (test_header_2 !== null && test_header_2 !== undefined) {
    _headers['test-header-2'] = test_header_2;
  }

  let formData = new FormData();
  formData.append('test_int', body.test_int.toString());
  formData.append('test_str', body.test_str);
  formData.append('test_file_1', body.test_file_1);
  formData.append('test_file_2', body.test_file_2);

  return fetch(_url, {
    method: 'post',
    headers: _headers,
    body: formData
  });
}


