import datetime
import decimal
import json
import os
from unittest import TestCase

from e2e.python.gen import api, deserializers


class PythonGeneratedCodeTestCase(TestCase):

    def assert_response_text_equal(self, response, expected):
        self.assertEqual(200, response.status_code)
        self.assertEqual(expected, response.text)

    def test_hello_world(self):
        response = api.test_hello_world()
        self.assert_response_text_equal(response, 'Hello test world!')

    def test_hello_world_with_url_param(self):
        response = api.test_hello_world_with_url_param(4)
        self.assert_response_text_equal(response, 'Hello test_url_param=4')

    def test_hello_world_with_query_param(self):
        response = api.test_hello_world_with_param(33)
        self.assert_response_text_equal(response, 'Hello test-query-param=33')

    def test_hello_world_with_header(self):
        response = api.test_hello_world_with_header(54)
        self.assert_response_text_equal(response, 'Hello test-header=54')

    def test_json_response(self):
        response = api.test_json_response()
        self.assertEqual({'testInt': 1, 'testBool': True, 'testString': 'testString',
                          'testDate': datetime.date(2000, 1, 1),
                          'testDateTime': datetime.datetime(2000, 1, 1, 12, 12, 12, 500000),
                          'testDecimal': decimal.Decimal('12.345')},
                         deserializers.deserialize_test_json_reponse_json(response.text))

    def test_json_echo(self):
        somejson = {'test_integer': 333333, 'test_decimal': decimal.Decimal('14.333')}
        response = api.test_json_echo(somejson)
        self.assertEqual({'test_integer': 333333, 'test_decimal': '14.333'}, json.loads(response.text))

    def test_json_echo_with_params_url_query_header(self):
        somejson = {'test_bool': False, 'test_list': [[3, 4], [5, 6]]}
        response = api.test_json_echo_with_params_url_query_header(somejson, '1', 2, 3, 4, False, 'tst')
        self.assertEqual({
            'test_url_param1': '1',
            'test_url_param2': 2,
            'test_query_param1': '3',
            'test_query_param2': '4',
            'test_header_1': 'false',
            'test_header_2': 'tst',
            'test_body': somejson
        }, json.loads(response.text))

    def test_form_data_with_params_url_query_header(self):
        data = {'test_int': 5, 'test_str': 'tst'}
        response = api.test_form_data_with_params_url_query_header(data, '1', 2, 3, 4, False, 'tst')

        self.assertEqual({
            'test_url_param1': '1',
            'test_url_param2': 2,
            'test_query_param1': '3',
            'test_query_param2': '4',
            'test_header_1': 'false',
            'test_header_2': 'tst',
            'test_form_data': {'test_int': 5, 'test_str': 'tst'}
        }, json.loads(response.text))

    def test_form_data_with_params_url_query_header_files(self):
        this_test_directory = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(this_test_directory, 'test_file_1')) as test_file_1:
            with open(os.path.join(this_test_directory, 'test_file_2')) as test_file_2:
                data = {'test_int': 5, 'test_str': 'tst', 'test_file_1': test_file_1, 'test_file_2': test_file_2}
                response = api.test_form_data_with_params_url_query_header_files(data, '1', 2, 3, 4, False, 'tst')
                self.assertEqual({
                    'test_url_param1': '1',
                    'test_url_param2': 2,
                    'test_query_param1': '3',
                    'test_query_param2': '4',
                    'test_header_1': 'false',
                    'test_header_2': 'tst',
                    'test_form_data': {'test_int': 5, 'test_str': 'tst'},
                    'test_file_1': 'test_file_1_content',
                    'test_file_2': 'test_file_2_content',
                }, json.loads(response.text))
