import json
import datetime
import decimal
import dateutil.parser


def deserialize_test_json_reponse_json(response_body):
    obj = json.loads(response_body)
    if obj.get('testDate') is not None:
        obj['testDate'] = dateutil.parser.parse(obj['testDate']).date()
    if obj.get('testDateTime') is not None:
        obj['testDateTime'] = dateutil.parser.parse(obj['testDateTime'])
    if obj.get('testDecimal') is not None:
        obj['testDecimal'] = decimal.Decimal(obj['testDecimal'])

    return obj


def deserialize_json_echo_response(response_body):
    obj = json.loads(response_body)
    
    return obj


def deserialize_test_form_data(response_body):
    obj = json.loads(response_body)
    
    return obj


def deserialize_test_form_data_return(response_body):
    obj = json.loads(response_body)
    
    return obj


def deserialize_test_json(response_body):
    obj = json.loads(response_body)
    
    return obj


def deserialize_test_form_data_with_file(response_body):
    obj = json.loads(response_body)
    
    return obj


def deserialize_test_form_data_with_file_return_type(response_body):
    obj = json.loads(response_body)
    
    return obj


