import datetime
import decimal
import json


class Py2RestEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return str(o)
        elif isinstance(o, datetime.date) or isinstance(o, datetime.datetime):
            return o.isoformat()
        return super(Py2RestEncoder, self).default(o)