import requests
import typing
import json

from .py2rest_encoder import Py2RestEncoder


def test_hello_world():
    """
    returns object:
    str, required: False
    """
    return requests.get('http://127.0.0.1:8000/test/test_hello_world')


def test_hello_world_with_url_param(test_url_param: int):
    """
    accepts url params:
    test_url_param - required: False, 
    returns object:
    str, required: False
    """
    return requests.get('http://127.0.0.1:8000/test/test_hello_world_with_url_param/{}'.format(test_url_param))


def test_hello_world_with_param(test_query_param: int):
    """
    accepts query params:
    test_query_param - required: False, 
    returns object:
    str, required: False
    """
    _params = {
        'test-query-param': str(test_query_param),
    }
    return requests.get('http://127.0.0.1:8000/test/test_hello_world_with_param', params=_params)


def test_hello_world_with_header(test_header: int):
    """
    accepts headers:
    test_header - required: False, 
    returns object:
    str, required: False
    """
    _headers = {
        'test-header': str(test_header),
    }
    return requests.get('http://127.0.0.1:8000/test/test_hello_world_with_header', headers=_headers)


def test_json_response():
    """
    returns object:
    {
      testInt: int, required: False
      testBool: bool, required: False
      testString: str, required: False
      testDate: datetime.date, required: False
      testDateTime: datetime.datetime, required: False
      testDecimal: decimal.decimal, required: False
    }, required: False
    """
    return requests.get('http://127.0.0.1:8000/test/test_json_response')


def test_json_echo(body: typing.Any):
    """
    accepts body:
    any
    returns object:
    any
    """
    return requests.post('http://127.0.0.1:8000/test/test_json_echo', data=json.dumps(body, cls=Py2RestEncoder))


def test_json_echo_with_params_url_query_header(body: typing.Any, test_url_param1: str, test_url_param2: int, test_query_param_1: int, test_query_param_2: int, test_header_1: bool, test_header_2: str):
    """
    accepts query params:
    test_query_param_1 - required: False, 
    test_query_param_2 - required: False, 
    accepts url params:
    test_url_param1 - required: False, 
    test_url_param2 - required: False, 
    accepts headers:
    test_header_1 - required: False, 
    test_header_2 - required: False, 
    accepts body:
    any
    returns object:
    {
      test_url_param1: str, required: False
      test_url_param2: int, required: False
      test_query_param1: str, required: False
      test_query_param2: str, required: False
      test_header_1: str, required: False
      test_header_2: str, required: False
      test_body: any
    }, required: False
    """
    _params = {
        'test-query-param-1': str(test_query_param_1),
        'test-query-param-2': str(test_query_param_2),
    }
    _headers = {
        'test-header-1': str(test_header_1).lower(),
        'test-header-2': str(test_header_2),
    }
    return requests.post('http://127.0.0.1:8000/test/test_json_echo_with_params_url_query_header/{}/{}'.format(test_url_param1, test_url_param2), params=_params, headers=_headers, data=json.dumps(body, cls=Py2RestEncoder))


def test_form_data_with_params_url_query_header(body: dict, test_url_param1: str, test_url_param2: int, test_query_param_1: int, test_query_param_2: int, test_header_1: bool, test_header_2: str):
    """
    accepts query params:
    test_query_param_1 - required: False, 
    test_query_param_2 - required: False, 
    accepts url params:
    test_url_param1 - required: False, 
    test_url_param2 - required: False, 
    accepts headers:
    test_header_1 - required: False, 
    test_header_2 - required: False, 
    accepts body:
    {
      test_int: int, required: False
      test_str: str, required: False
    }, required: False
    returns object:
    {
      test_url_param1: str, required: False
      test_url_param2: int, required: False
      test_query_param1: str, required: False
      test_query_param2: str, required: False
      test_header_1: str, required: False
      test_header_2: str, required: False
      test_form_data: {
        test_int: int, required: False
        test_str: str, required: False
      }, required: False
    }, required: False
    """
    _params = {
        'test-query-param-1': str(test_query_param_1),
        'test-query-param-2': str(test_query_param_2),
    }
    _headers = {
        'test-header-1': str(test_header_1).lower(),
        'test-header-2': str(test_header_2),
    }
    _form_data = {
        'test_int': body.get('test_int'),
        'test_str': body.get('test_str'),
    }

    return requests.post('http://127.0.0.1:8000/test/test_form_data_with_params_url_query_header/{}/{}'.format(test_url_param1, test_url_param2), params=_params, headers=_headers, data=_form_data)


def test_form_data_with_params_url_query_header_files(body: dict, test_url_param1: str, test_url_param2: int, test_query_param_1: int, test_query_param_2: int, test_header_1: bool, test_header_2: str):
    """
    accepts query params:
    test_query_param_1 - required: False, 
    test_query_param_2 - required: False, 
    accepts url params:
    test_url_param1 - required: False, 
    test_url_param2 - required: False, 
    accepts headers:
    test_header_1 - required: False, 
    test_header_2 - required: False, 
    accepts body:
    {
      test_int: int, required: False
      test_str: str, required: False
      test_file_1: File
      test_file_2: File
    }, required: False
    returns object:
    {
      test_url_param1: str, required: False
      test_url_param2: int, required: False
      test_query_param1: str, required: False
      test_query_param2: str, required: False
      test_header_1: str, required: False
      test_header_2: str, required: False
      test_form_data: {
        test_int: int, required: False
        test_str: str, required: False
      }, required: False
      test_file_1: str, required: False
      test_file_2: str, required: False
    }, required: False
    """
    _params = {
        'test-query-param-1': str(test_query_param_1),
        'test-query-param-2': str(test_query_param_2),
    }
    _headers = {
        'test-header-1': str(test_header_1).lower(),
        'test-header-2': str(test_header_2),
    }
    _form_data = {
        'test_int': body.get('test_int'),
        'test_str': body.get('test_str'),
    }
    _files = {
        'test_file_1': body.get('test_file_1'),
        'test_file_2': body.get('test_file_2'),
    }

    return requests.post('http://127.0.0.1:8000/test/test_form_data_with_params_url_query_header_files/{}/{}'.format(test_url_param1, test_url_param2), params=_params, headers=_headers, data=_form_data, files=_files)


