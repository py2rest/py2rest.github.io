Py2rest code repository.

/e2e contains end-to-end test code
/py2rest contains library code as well as unit/integration tests