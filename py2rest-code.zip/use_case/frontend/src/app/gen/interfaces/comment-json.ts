
export interface CommentJSON {
  id?: number;
  author: string;
  content: string;
  likesCount?: number;
  createdDate?: Date;
}
