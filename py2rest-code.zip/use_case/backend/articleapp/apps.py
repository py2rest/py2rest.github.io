from django.apps import AppConfig


class ArticleappConfig(AppConfig):
    name = 'articleapp'
