import logging
from typing import List

from py2rest import api_endpoint
from py2rest.argresolvers import ArgResolver
from py2rest.engines.engine import Engine
from py2rest.errors import Py2RestConfigError
from py2rest.fileio import FileIO

logger = logging.getLogger('py2rest')


class Py2Rest:
    """
    Main configuration class, responsible for reading endpoints, passing them to used generation engines, and
    passing generation results to class responsible for final writing to disk.
    """

    def __init__(self, base_url: str, engines: List[Engine], arg_resolver: ArgResolver = None):
        self.base_url = base_url
        self.engines = engines
        self.endpoints = []
        self.arg_resolver = arg_resolver
        logger.setLevel(logging.INFO)

    def read_decorated_endpoints(self):
        self.endpoints = api_endpoint.api_endpoint_registry

    def generate(self):
        Py2Rest._validate_endpoints(self.endpoints)
        if self.arg_resolver is not None:
            self.arg_resolver.resolve_arguments(self.endpoints)
        gen_files = []

        for engine in self.engines:
            engine.prepare(self.base_url, self.endpoints)
            gen_files = gen_files + engine.generate()

        FileIO().write_files(gen_files)

    @staticmethod
    def _validate_endpoints(endpoints):
        seen_group_name_tuples = set()
        invalid_group_name_tuples = set()
        for endpoint in endpoints:
            if (endpoint.group_name, endpoint.name) in seen_group_name_tuples:
                invalid_group_name_tuples.add((endpoint.group_name, endpoint.name))
            else:
                seen_group_name_tuples.add((endpoint.group_name, endpoint.name))

        if invalid_group_name_tuples:
            stringified_tuples = ['({},{})'.format(grp_name, name) for grp_name, name in invalid_group_name_tuples]
            raise Py2RestConfigError('Multiple declarations for group_name, name combinations: ' '; '
                                     .join(stringified_tuples))
