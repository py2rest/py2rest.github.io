class Py2RestConfigError(Exception):
    """
    Exception used to notify user that he documented his API incorrectly.
    """
    pass
