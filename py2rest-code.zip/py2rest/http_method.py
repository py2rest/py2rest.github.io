
class HttpMethod:
    """
    HttpMethod enum. Use http_method.GET, http_method.POST, ... instances from this module rather than creating one
    yourself.
    """

    def __init__(self, name: str, supports_body: bool):
        self.name = name
        self.supports_body = supports_body


GET = HttpMethod('get', False)
POST = HttpMethod('post', True)
PUT = HttpMethod('put', True)
DELETE = HttpMethod('delete', False)
OPTIONS = HttpMethod('options', False)
PATCH = HttpMethod('patch', True)
