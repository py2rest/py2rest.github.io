import logging
import re
from typing import List

from py2rest.api.fields import FormData, JSONObject, AnyField, CharField
from py2rest.api.parameter import Parameter
from py2rest.errors import Py2RestConfigError
from py2rest.http_method import HttpMethod

logger = logging.getLogger('py2rest')


class Endpoint:
    """
    General API endpoint description class. Contains all concerned parameters, still generalized in Python,
    so later they can be mapped to more specific classes corresponding to individual endpoint handling, i.e.
    to angular service method responsible for calling given endpoint.
    """

    URL_PARAM_REGEX = r'\{(.+?)\}'

    def __init__(self, controller, url: str = None, method: HttpMethod = None, url_params: List[Parameter] = None,
                 query_params: List[Parameter] = None, headers: List[Parameter] = None, body=None, return_type=None,
                 group_name: str = 'api', name: str = None):
        Endpoint._validate(method, url_params, query_params, headers, body, return_type, group_name, name)
        self.controller = controller
        self.url = url
        self.method = method
        self.url_params = url_params or []
        self.query_params = query_params or []
        self.headers = headers or []
        self.body = body
        self.return_type = return_type
        self.group_name = group_name
        if name is None:
            if controller is None:
                raise Py2RestConfigError('Either name or controller needs to be provided')
            name = method.name + controller.__name__
        self.name = name

    def pre_validate(self) -> bool:
        if self.url is not None:
            for param_regex_group in re.finditer(Endpoint.URL_PARAM_REGEX, self.url):
                if param_regex_group.group(1) not in (param.name for param in self.url_params):
                    logger.warning('Could not find url param {} for endpoint {}'.format(param_regex_group.group(1), self))
                    return False
        return True

    @staticmethod
    def _validate(method, url_params, query_params, headers, body, return_type, group_name, name):
        fail_reasons = []

        if not isinstance(method, HttpMethod):
            fail_reasons.append('method must be instance of HttpMethod')

        if not (url_params is None or Endpoint._is_list_of_parameters(url_params)):
            fail_reasons.append('url_params must be an iterable of Parameter instances')

        if not (query_params is None or Endpoint._is_list_of_parameters(query_params)):
            fail_reasons.append('query_params must be an iterable of Parameter instances')

        if not (headers is None or Endpoint._is_list_of_parameters(headers)):
            fail_reasons.append('headers must be an iterable of Parameter instances')

        if body is not None and not Endpoint._is_allowed_body_or_return_type(body):
            fail_reasons.append('{} is not a valid body'.format(body))

        if return_type is not None and not Endpoint._is_allowed_body_or_return_type(return_type):
            fail_reasons.append('{} is not a valid return type'.format(return_type))

        if not str(group_name) == group_name:
            fail_reasons.append('group_name should be a string')

        if name is not None and not str(name) == name:
            fail_reasons.append('name should be a string')

        if fail_reasons:
            raise Py2RestConfigError('Invalid endpoint: {}'.format('; '.join(fail_reasons)))

    @staticmethod
    def _is_list_of_parameters(lst):
        try:
            for obj in lst:
                if not isinstance(obj, Parameter):
                    return False
            return True
        except TypeError:
            return False


    @staticmethod
    def _is_allowed_body_or_return_type(body_or_return_type):
        allowed_classes = [CharField, AnyField, JSONObject, FormData]
        for cls in allowed_classes:
            if isinstance(body_or_return_type, cls):
                return True
        return False

    def __str__(self) -> str:
        return 'url: {} - method: {}'.format(self.url, self.method)
