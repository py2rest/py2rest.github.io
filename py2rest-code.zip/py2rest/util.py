import re

# py2rest utility functions


def to_spinalcase(name):
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1-\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1-\2', s1).lower()


def to_snakecase(name):
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def escape_forbidden_variable_name_symbols(variable_name: str):
    escaped = list(variable_name)
    # escape first symbol
    if not re.match(r'[a-zA-Z_$]', escaped[0]):
        escaped[0] = '_'

    for index, character in enumerate(escaped[1:]):
        if not re.match(r'[0-9a-zA-Z_$]', character):
            escaped[index + 1] = '_'

    return ''.join(escaped)


def module_qualified_name(obj):
    return obj.__module__ + '.' + obj.__name__


def next_obj_name(obj_name):
    if len(obj_name) == len('obj'):
        return 'obj1'
    else:
        count = int(obj_name[len('obj'):]) + 1
        return 'obj' + str(count)


def next_index_name(index_name):
    if index_name is None:
        return 'a'
    else:
        return chr(ord(index_name) + 1)
