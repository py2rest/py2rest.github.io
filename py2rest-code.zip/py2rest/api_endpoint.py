import logging
from typing import List

from py2rest.api.parameter import Parameter
from py2rest.endpoint import Endpoint
from py2rest.http_method import HttpMethod

logger = logging.getLogger('py2rest')

logging.basicConfig(level=logging.INFO)

api_endpoint_registry = []


def api_endpoint(url: str = None, method: HttpMethod = None, url_params: List[Parameter] = None,
                 query_params: List[Parameter] = None, headers: List[Parameter] = None, body=None, return_type=None,
                 group_name: str = 'api', name: str = None):
    """
    main decorator used to document API endpoints
    :param url: url of endpoint, if it contains variables, use {variable_name} in their place, i.e. /article/{id}
    :param method: http method handled by endpoint
    :param url_params: parameters used in url, name should reference variable name used in url parameter
    :param query_params: query parameters handled by endpoint
    :param headers: headers handled by endpoint
    :param body: request body expected by endpoint
    :param return_type: JSONObject structure returned by endpoint
    :param group_name: what group this endpoint belongs to. Endpoints with same group_name will be created
    in file that is based on group_name, adjusted to fit generated code conventions, i.e. in angular {group_name}.service.ts
    :param name: unique per group_name identifier, name is used as function name for responding part of generated code
    """
    def actual_decorator(controller):
        api_endpoint_registry.append(Endpoint(controller, url, method, url_params,
                                              query_params, headers, body, return_type,
                                              group_name, name))

        logger.info('Discovered api endpoint controller=%s, url=%s, method=%s, url_params=%s, query_params=%s,'
                    'headers=%s, body=%s, return_type=%s, group_name=%s, name=%s', controller, url, method,
                    url_params,
                    query_params, headers, body,
                    return_type,
                    group_name, name)

        return controller

    return actual_decorator
