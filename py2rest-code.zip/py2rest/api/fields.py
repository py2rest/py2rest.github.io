from abc import ABC, abstractmethod

from py2rest.errors import Py2RestConfigError


class Field(ABC):
    """
    Abstract field used to describe data structures in py2rest
    """

    def __init__(self, required=False, description='', *args, **kwargs):
        self._validate(required, description)
        self.required = required
        self.description = description
        self.args = args
        self.kwargs = kwargs

    def _validate(self, required, description):
        if not type(required) == bool:
            raise Py2RestConfigError('required must be bool')

        if not str(description) == description:
            raise Py2RestConfigError('description must be string')

    @abstractmethod
    def accept(self, name: str, visitor):
        pass


class ListField(Field):

    def __init__(self, element_type, required=False, description='', *args, **kwargs):
        super().__init__(required, description, *args, **kwargs)
        self._validate_el_type(element_type)
        self.element_type = element_type

    def _validate_el_type(self, element_type):
        if not isinstance(element_type, Field) or isinstance(element_type, FormData):
            raise Py2RestConfigError('Element type must be a field or jsonobject')

    def accept(self, name: str, visitor):
        visitor.visit_list_field(name, self)


class CharField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_char_field(name, self)


class IntegerField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_integer_field(name, self)


class DecimalField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_decimal_field(name, self)


class FloatField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_float_field(name, self)


class DateTimeField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_datetime_field(name, self)


class DateField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_date_field(name, self)


class BooleanField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_boolean_field(name, self)


class AnyField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_any_field(name, self)


class Dto(Field):

    @abstractmethod
    def accept(self, name: str, visitor):
        pass

    @classmethod
    def get_fields(cls):
        """
        Retrieve Field or Dto class members
        """
        fields = []
        for fieldname, field in vars(cls).items():
            if isinstance(field, Field):
                fields.append((fieldname, field))

        return fields


class JSONObject(Dto):
    """
    Base class for JSON data structures in py2rest. Should have class members describing individual JSON fields, i.e.
    class MyJSON(JSONObject):
        myInt = fields.IntegerField()
    """

    def accept(self, name: str, visitor):
        visitor.visit_jsonobject(name, self)


class FormData(Dto):
    """
    Base class for FormData data structures in py2rest. Should have class members describing individual FormData fields, i.e.
    class MyFormData(FormData):
        myInt = fields.IntegerField()
    """

    def accept(self, name: str, visitor):
        visitor.visit_formdata(name, self)


class FileUploadField(Field):

    def accept(self, name: str, visitor):
        visitor.visit_file_upload_field(name, self)
