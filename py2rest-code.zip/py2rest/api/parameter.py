import datetime
from typing import Type

from py2rest.errors import Py2RestConfigError
from py2rest.util import escape_forbidden_variable_name_symbols


class Parameter:
    """
    Class used to describe API endpoint url, query parameters and headers.
    """

    def __init__(self, name: str, type: Type, required=False, description='', gen_name: str = None, *args, **kwargs):
        self._validate_param(name, type, required, description, gen_name)
        self.name = name
        self.type = type
        self.gen_name = gen_name or escape_forbidden_variable_name_symbols(name).lower()
        self.required = required
        self.description = description
        self.args = args
        self.kwargs = kwargs

    def _validate_param(self, name, param_type, required, description, gen_name):
        fail_reasons = []

        if not str(name) == name:
            fail_reasons.append('Param name should be a string')

        if not (param_type in (int, bool, datetime.date, datetime.datetime, float, str, None)):
            fail_reasons.append('Param type should be one of '
                                '(int, bool, datetime.date, datetime.datetime, float, str, None)')

        if gen_name is not None and not str(gen_name) == gen_name:
            fail_reasons.append('Param gen_name should be a string')

        if not str(description) == description:
            fail_reasons.append('Description should be a string')

        if not type(required) == bool:
            fail_reasons.append('Required should be a boolean')

        if fail_reasons:
            raise Py2RestConfigError('Invalid param: {}'.format('; '.join(fail_reasons)))
