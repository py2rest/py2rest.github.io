import logging
import os
from typing import List

from py2rest.engines.generated_file import GeneratedFile

logger = logging.getLogger('py2rest')


class FileIO:
    """
    Class responsible for final writing generated files to filesystem.
    """

    def write_files(self, gen_files: List[GeneratedFile]):
        for file in gen_files:
            logger.info('Writing file %s', file.path)
            if not os.path.exists(os.path.dirname(file.path)):
                os.makedirs(os.path.dirname(file.path))

            with open(file.path, "w") as f:
                f.write(file.contents)
