import logging
import re
from abc import ABC, abstractmethod
from typing import List

from py2rest.api.parameter import Parameter
from py2rest.endpoint import Endpoint
from py2rest.util import module_qualified_name

logger = logging.getLogger('py2rest')


class ArgResolver(ABC):
    """
    ArgResolver allows to deduct some endpoint parameters from used framework if they are available, so programmer
    does not have to repeat them and violate DRY principle. For example you can deduct URL and URL parameters in Django
    from the urlpatterns setting using DjangoArgResolver
    """

    @abstractmethod
    def resolve_arguments(self, endpoints: List[Endpoint]):
        pass


class DjangoArgResolver(ArgResolver):
    """
    Deducts URL and URL parameters from Django urlpatterns. For this to work @api_endpoint must be used on Django view.
    If Django View Classes @api_endpoint must be used on class itself rather than individual class method.
    If view functions are used, @api_endpoint should decorate the function.
    """

    def __init__(self):
        from django.urls.converters import IntConverter, PathConverter, SlugConverter, StringConverter, UUIDConverter
        self._CONVERTER_REGEX = r"<(.+?):(.+?)>"
        self._CONVERTERS_TO_FIELDS = {
            IntConverter: int,
            PathConverter: str,
            SlugConverter: str,
            StringConverter: str,
            UUIDConverter: str
        }

    def resolve_arguments(self, endpoints: List[Endpoint]):
        view_to_url_mapping = self._find_views()

        for endpoint in endpoints:
            if endpoint.controller and endpoint.url is None:
                endpoint.url, endpoint.url_params = view_to_url_mapping[module_qualified_name(endpoint.controller)]

    def _find_views(self):
        """Searches django urlpatterns for view function or class <-> url mappings and returns them
         as dict (view_func_or_class -> EndpointUrl)"""
        from django.urls import get_resolver

        main_resolver = get_resolver(None)
        found_views = {}
        view_to_url_mapping = dict()
        for urlpattern_or_resolver in main_resolver.url_patterns:
            self._add_found_views(urlpattern_or_resolver, found_views, str(urlpattern_or_resolver.pattern),
                                  urlpattern_or_resolver.pattern.converters, view_to_url_mapping)

        return view_to_url_mapping

    def _add_found_views(self, urlpattern_or_resolver, found_views, route_so_far, converters_so_far,
                         view_to_url_mapping):
        try:
            for urlpattern_or_resolver_lower in urlpattern_or_resolver.url_patterns:  # has children - it is urlresolver
                converters_so_far.update(urlpattern_or_resolver_lower.pattern.converters)
                self._add_found_views(urlpattern_or_resolver_lower, found_views,
                                      route_so_far + str(urlpattern_or_resolver_lower.pattern),
                                      converters_so_far,
                                      view_to_url_mapping)
        except AttributeError as E:  # doesn't have urlpatterns/resolver beneath it - meaning it is lowest level urlpattern
            full_pattern = route_so_far

            if hasattr(urlpattern_or_resolver.callback, 'view_class'):  # class based
                view_to_url_mapping[module_qualified_name(urlpattern_or_resolver.callback.view_class)] = \
                    self._parse_url(full_pattern, converters_so_far)
            else:  # function based
                view_to_url_mapping[module_qualified_name(urlpattern_or_resolver.callback)] = \
                    self._parse_url(full_pattern, converters_so_far)

    def _parse_url(self, url, converters):
        converter_groups = re.finditer(self._CONVERTER_REGEX, url)
        url_params = []

        # converter_regex_group example: <int:id>
        for converter_regex_group in converter_groups:
            param_name = converter_regex_group.group(2)
            param_type = str
            converter = converters.get(param_name, None).__class__
            try:
                param_type = self._CONVERTERS_TO_FIELDS[converter]
            except KeyError:
                try:
                    param_type = converter.PARAM_TYPE
                except AttributeError:
                    logger.info("Converter {} in url {} is not default django converter and does not have "
                                "class property PARAM_TYPE defined. Falling back to 'str' type",
                                str(converter_regex_group), url)

            url_params.append(Parameter(param_name, param_type))

        url = '/' + re.sub(self._CONVERTER_REGEX, r"{\2}", url)

        return url, url_params
