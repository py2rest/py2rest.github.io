import os
import re
from datetime import datetime, date
from typing import List

from py2rest.endpoint import Endpoint
from py2rest.engines.config import jinja_env
from py2rest.engines.engine import Engine
from py2rest.engines.generated_file import GeneratedFile
from py2rest.engines.python.py_types import PyString, PyFloat, PyDateTime, PyDate, PyInt, PyBool, PyType
from py2rest.engines.python.py_visitor import PyVisitor
from py2rest.util import to_snakecase

PYTHON_TO_PY_TYPE = {
    int: PyInt(),
    bool: PyBool(),
    date: PyDate(),
    datetime: PyDateTime(),
    float: PyFloat(),
    str: PyString()
}


class PyParameter:

    def __init__(self, name: str, gen_name: str, type: PyType, required=False, description=''):
        self.name = name
        self.gen_name = gen_name
        self.type = type
        self.required = required
        self.description = description

    @classmethod
    def from_parameter(cls, parameter):
        return cls(parameter.name, parameter.gen_name, PYTHON_TO_PY_TYPE[parameter.type],
                   parameter.required, parameter.description)

    def get_string_conversion(self):
        default_conversion = 'str({})'.format(self.gen_name)
        if isinstance(self.type, PyBool):
            return default_conversion + '.lower()'
        return default_conversion


def prepare_py_url_for_formatting(base_url: str, url: str, url_params: List[PyParameter]):
    ordered_params = []

    for param_regex_group in re.finditer(Endpoint.URL_PARAM_REGEX, url):
        ordered_params.append([param for param in url_params if param.name == param_regex_group.group(1)][0])

    prepared_url = base_url + re.sub(Endpoint.URL_PARAM_REGEX, '{}', url)

    return prepared_url, ordered_params


class RequestMethod:

    def __init__(self, url, method, url_params, query_params, headers, body, return_type, name):
        self.name = name
        self.body = body
        self.url_params = url_params
        self.headers = headers
        self.url = url
        self.method = method
        self.query_params = query_params
        self.return_type = return_type

    def get_all_parameters(self):
        def_params = self.url_params + self.query_params + self.headers
        if self.body:
            def_params.insert(0, PyParameter(name='body', gen_name='body', type=self.body))

        return def_params


class PythonRequestsEngine(Engine):
    """
    Python requests generation engine
    """

    def __init__(self, generation_path=None):
        super().__init__(generation_path, 'python')
        self.file_name_to_method = dict()
        self.dto_to_interface = dict()
        self.visitor = PyVisitor(self.dto_to_interface)

    def prepare(self, base_url, endpoints: List[Endpoint]):

        for endpoint in endpoints:
            curr_endpoint_body = None
            curr_endpoint_return_type = None
            if endpoint.body is not None:
                curr_endpoint_body = self.visitor.visit(endpoint.body)
            if endpoint.return_type is not None:
                curr_endpoint_return_type = self.visitor.visit(endpoint.return_type)

            url, url_params = prepare_py_url_for_formatting(
                base_url, endpoint.url, [PyParameter.from_parameter(p) for p in endpoint.url_params]
            )

            method = RequestMethod(url=url, method=endpoint.method,
                                   url_params=url_params,
                                   query_params=[PyParameter.from_parameter(p) for p in endpoint.query_params],
                                   headers=[PyParameter.from_parameter(p) for p in endpoint.headers],
                                   body=curr_endpoint_body,
                                   return_type=curr_endpoint_return_type,
                                   name=endpoint.name)

            self.file_name_to_method.setdefault(endpoint.group_name, []).append(method)

    def generate(self):
        gen_files = [GeneratedFile(os.path.join(self.generation_path, to_snakecase(file_name) + '.py'),
                                   jinja_env.get_template('py_requests/py_requests.py.jinja2').render(methods=methods))
                     for file_name, methods in self.file_name_to_method.items()]
        gen_files.append(
            GeneratedFile(
                os.path.join(self.generation_path, 'py2rest_encoder.py'),
                jinja_env.get_template('py_requests/py_encoder.py').render()
            )
        )
        gen_files.append(
            GeneratedFile(
                os.path.join(self.generation_path, 'deserializers.py'),
                jinja_env.get_template('py_requests/deserializers.py.jinja2').render(pydicts=self.dto_to_interface.values())
            )
        )
        return gen_files
