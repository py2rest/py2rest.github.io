from py2rest.api.fields import ListField, CharField, IntegerField, DecimalField, FloatField, DateTimeField, DateField, \
    BooleanField, FileUploadField, AnyField
from py2rest.engines.common.visitor import DefaultVisitor
from py2rest.engines.python.py_types import PyString, PyList, PyInt, PyFloat, PyDateTime, PyDate, PyBool, PyFile, \
    PyDecimal, PyDict, PyAny


class PyVisitor(DefaultVisitor):

    FIELD_TO_TYPE = {
        ListField: PyList,
        CharField: PyString,
        IntegerField: PyInt,
        DecimalField: PyDecimal,
        FloatField: PyFloat,
        DateTimeField: PyDateTime,
        DateField: PyDate,
        BooleanField: PyBool,
        FileUploadField: PyFile,
        AnyField: PyAny
    }

    def __init__(self, dto_to_interface: dict):
        super().__init__(PyVisitor.FIELD_TO_TYPE, PyDict, dto_to_interface)
