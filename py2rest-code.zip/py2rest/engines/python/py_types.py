from typing import List

from py2rest.engines.common.base_interface import BaseInterface
from py2rest.engines.config import jinja_env
from py2rest.util import to_snakecase, next_obj_name, next_index_name


# this module contains classes corresponding to python specific types


class PyType:

    def __init__(self, identifier: str, required=False, description='', *args, **kwargs):
        self.identifier = identifier
        self.required = required
        self.description = description
        self.args = args
        self.kwargs = kwargs

    def get_type_doc(self):
        doc = '{}, required: {}'.format(self.identifier, self.required)

        if self.description:
            doc = doc + ', description: {}'.format(self.description)

        return doc


class PyField:

    def __init__(self, name: str, type: PyType):
        self.name = name
        self.type = type


class PyList(PyType):

    def __init__(self, element_type: PyType, required=False, description='', *args, **kwargs):
        self.element_type = element_type
        super().__init__('List[{}]'.format(element_type.identifier), required, description, *args, **kwargs)

    def is_final_element_complex(self):
        if isinstance(self.element_type, PyList):
            return self.element_type.is_final_element_complex()
        elif isinstance(self.element_type, PyDict):
            return self.element_type.dicts_lists or self.element_type.dates_decimals
        else:
            return type(self.element_type) in (PyDateTime, PyDate, PyDecimal)

    def get_type_doc(self):
        doc = '[{}], required: {}'.format(self.element_type.get_type_doc(), self.required)

        if self.description:
            doc = doc + ', description: {}'.format(self.description)

        return doc

    def get_deserialization(self, obj_name, index_name):
        return jinja_env.get_template('py_requests/py_list_deserialization.jinja2') \
            .render(obj_name=obj_name, list=self, next_obj_name=next_obj_name,
                    complex_element_type=type(self.element_type) in [PyDict, PyList],
                    next_index_name=next_index_name, index_name=index_name)


class PyString(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('str', required, description, *args, **kwargs)


class PyInt(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('int', required, description, *args, **kwargs)


class PyDecimal(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('decimal.decimal', required, description, *args, **kwargs)

    def get_deserialization(self, obj_name):
        return 'decimal.Decimal({})'.format(obj_name)


class PyFloat(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('float', required, description, *args, **kwargs)


class PyDateTime(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('datetime.datetime', required, description, *args, **kwargs)

    def get_deserialization(self, obj_name):
        return 'dateutil.parser.parse({})'.format(obj_name)


class PyDate(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('datetime.date', required, description, *args, **kwargs)

    def get_deserialization(self, obj_name):
        return 'dateutil.parser.parse({}).date()'.format(obj_name)


class PyBool(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('bool', required, description, *args, **kwargs)


class PyFile(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('typing.IO', required, description, *args, **kwargs)

    def get_type_doc(self):
        return 'File'


class PyAny(PyType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('typing.Any', required, description, *args, **kwargs)

    def get_type_doc(self):
        return 'any'


class PyDict(PyType, BaseInterface):

    def __init__(self, identifier, dto_type, required=False, description='', *args, **kwargs):
        super().__init__('dict', required, description, *args, **kwargs)
        self.type_identifier = identifier
        self.snake_case_identifier = to_snakecase(identifier)
        self.py_fields: List[PyField] = []
        self.is_already_parsed: bool = False
        self.dto_type = dto_type
        self.files = []
        self.dates_decimals = []
        self.dicts_lists = []

    def add_field(self, name: str, pytype: PyType):
        field = PyField(name, pytype)
        if isinstance(pytype, PyFile):
            self.files.append(field)
        else:
            self.py_fields.append(field)
            if type(pytype) in (PyDecimal, PyDate, PyDateTime):
                self.dates_decimals.append(field)
            elif isinstance(pytype, PyDict) and (pytype.dicts_lists or pytype.dates_decimals):
                self.dicts_lists.append(field)
            elif isinstance(pytype, PyList) and pytype.is_final_element_complex():
                self.dicts_lists.append(field)

    def get_type_doc(self):
        return jinja_env.get_template('py_requests/py_type_doc.jinja2')\
            .render(identifier=self.type_identifier, fields=self.py_fields + self.files, required=self.required,
                    description=self.description)

    def get_deserialization(self, obj_name, index_name):
        return jinja_env.get_template('py_requests/py_dict_deserialization.jinja2') \
            .render(obj_name=obj_name, dict=self, next_obj_name=next_obj_name,
                    next_index_name=next_index_name, index_name=index_name)
