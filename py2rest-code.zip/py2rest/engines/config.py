from jinja2 import Environment, PackageLoader

jinja_env = Environment(
    loader=PackageLoader('py2rest.engines', 'templates'),
    trim_blocks=True,
    lstrip_blocks=True
)
