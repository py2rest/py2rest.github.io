from py2rest.api.fields import ListField, CharField, IntegerField, DecimalField, FloatField, DateTimeField, DateField, \
    BooleanField, FileUploadField, AnyField
from py2rest.engines.common.visitor import DefaultVisitor
from py2rest.engines.ts.ts_types import TsInterface, TsBoolean, TsList, TsDate, TsNumber, TsString, TsFile, TsAny


class TsVisitor(DefaultVisitor):

    FIELD_TO_TYPE = {
        ListField: TsList,
        CharField: TsString,
        IntegerField: TsNumber,
        DecimalField: TsString,
        FloatField: TsString,
        DateTimeField: TsDate,
        DateField: TsDate,
        BooleanField: TsBoolean,
        FileUploadField: TsFile,
        AnyField: TsAny
    }

    def __init__(self, dto_to_interface: dict):
        super().__init__(TsVisitor.FIELD_TO_TYPE, TsInterface, dto_to_interface)
