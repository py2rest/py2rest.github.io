from typing import List

from py2rest.engines.common.base_interface import BaseInterface
from py2rest.engines.config import jinja_env
from py2rest.util import to_spinalcase, next_obj_name, next_index_name

# This module describes typescript types used during py2rest generation for Fetch API and Angular
# In py2rest Fetch API uses typescript classes under the hood but does not include type declarations in arguments
# in jinja2 templates


class TsType:

    def __init__(self, identifier: str, required=False, description='', *args, **kwargs):
        self.identifier = identifier
        self.required = required
        self.description = description
        self.args = args
        self.kwargs = kwargs

    @staticmethod
    def get_string_conversion():
        return '.toString()'

    def get_response_type(self):
        return 'text'

    def needs_generic_method(self):
        return False

    def get_type_doc(self):
        return self.identifier


class TsField:

    def __init__(self, name: str, type: TsType):
        self.name = name
        self.type = type


class TsBoolean(TsType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('boolean', required, description, *args, **kwargs)


class TsDate(TsType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('Date', required, description, *args, **kwargs)

    @staticmethod
    def get_string_conversion():
        return '.toISOString()'

    def get_deserialization(self, obj_name):
        return 'new Date({})'.format(obj_name)


class TsNumber(TsType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('number', required, description, *args, **kwargs)


class TsString(TsType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('string', required, description, *args, **kwargs)

    @staticmethod
    def get_string_conversion():
        return ''


class TsList(TsType):

    def __init__(self, element_type: TsType, required=False, description='', *args, **kwargs):
        self.element_type = element_type
        super().__init__('{}[]'.format(element_type.identifier, required, description, *args, **kwargs))

    def get_final_type(self):
        if isinstance(self.element_type, TsList):
            return self.element_type.get_final_type()
        else:
            return self.element_type

    def get_response_type(self):
        return 'json'

    def get_type_doc(self):
        return self.element_type.get_type_doc() + '[]'

    def is_final_element_complex(self):
        if isinstance(self.element_type, TsList):
            return self.element_type.is_final_element_complex()
        elif isinstance(self.element_type, TsInterface):
            return self.element_type.interfaces_lists or self.element_type.dates
        else:
            return isinstance(self.element_type, TsDate)

    def get_deserialization(self, obj_name, index_name):
        return jinja_env.get_template('fetchapi/js_list_deserialization.jinja2') \
            .render(obj_name=obj_name, list=self, next_obj_name=next_obj_name,
                    complex_element_type=type(self.element_type) in [TsInterface, TsList],
                    next_index_name=next_index_name, index_name=index_name)


class TsAny(TsType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('any', required, description, *args, **kwargs)

    def get_response_type(self):
        return 'json'


class TsFile(TsType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('File', required, description, *args, **kwargs)

    @staticmethod
    def get_string_conversion():
        return ''

    def get_response_type(self):
        return 'blob'


class TsInterface(TsType, BaseInterface):

    def __init__(self, identifier, dto_type, required=False, description='', *args, **kwargs):
        super().__init__(identifier, required, description, *args, **kwargs)
        self.ts_fields: List[TsField] = []
        self.is_already_parsed: bool = False
        self.dto_type = dto_type
        self.dates = []
        self.interfaces_lists = []
        self.required_imports = set()
        self.filename_no_extension = to_spinalcase(identifier)

    def add_field(self, name: str, tstype: TsType):
        field = TsField(name, tstype)
        self.ts_fields.append(field)
        final_type = tstype.get_final_type() if isinstance(tstype, TsList) else tstype
        if isinstance(final_type, TsInterface):
            self.required_imports.add(final_type)

        if isinstance(tstype, TsDate):
            self.dates.append(field)
        elif isinstance(tstype, TsInterface) and (tstype.interfaces_lists or tstype.dates):
            self.interfaces_lists.append(field)
        elif isinstance(tstype, TsList) and tstype.is_final_element_complex():
            self.interfaces_lists.append(field)

    def get_response_type(self):
        return 'text'

    def needs_generic_method(self):
        return True

    def get_type_doc(self):
        return jinja_env.get_template('fetchapi/js_type_doc.jinja2') \
            .render(identifier=self.identifier, fields=self.ts_fields)

    def get_deserialization(self, obj_name, index_name):
        return jinja_env.get_template('fetchapi/js_object_deserialization.jinja2') \
            .render(obj_name=obj_name, object=self, index_name=index_name,
                    next_obj_name=next_obj_name, next_index_name=next_index_name)
