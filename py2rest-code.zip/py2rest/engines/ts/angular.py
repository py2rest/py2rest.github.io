import os
import re
import sys
from datetime import date, datetime
from typing import List, Set

from py2rest.endpoint import Endpoint
from py2rest.engines.ts.ts_types import TsType, TsNumber, TsDate, TsBoolean, TsAny, TsInterface, TsString
from py2rest.engines.ts.ts_util import adapt_ts_url
from py2rest.engines.ts.ts_visitor import TsVisitor
from py2rest.engines.config import jinja_env
from py2rest.engines.engine import Engine
from py2rest.engines.generated_file import GeneratedFile
from py2rest.http_method import HttpMethod
from py2rest.util import to_spinalcase

PYTHON_TO_TS_TYPE = {
    int: TsNumber(),
    bool: TsBoolean(),
    date: TsDate(),
    datetime: TsDate(),
    float: TsNumber(),
    str: TsString(),
    None: TsAny()
}


class TsParameter:
    """
    Class responsible for describing url, query params or headers specifically in angular
    """

    def __init__(self, name: str, gen_name: str, type: TsType, required=False, description=''):
        self.name = name
        self.gen_name = gen_name
        self.type = type
        self.required = required
        self.description = description

    @classmethod
    def from_parameter(cls, parameter):
        return cls(parameter.name, parameter.gen_name, PYTHON_TO_TS_TYPE[parameter.type], parameter.required,
                   parameter.description)


class AngularMethod:
    """
    Class responsible for describing single method in Angular Service class
    """

    def __init__(self, url: str, method: HttpMethod, url_params: List[TsParameter],
                 query_params: List[TsParameter], headers: List[TsParameter], body: TsType, return_type: TsType,
                 name: str):
        self.name = name
        self.body = body
        self.url_params = url_params
        self.headers = headers
        self.url = url
        self.method = method
        self.query_params = query_params
        self.return_type = return_type
        self.needs_null_body = body is None and method.supports_body

    def get_all_parameters(self):
        def_params = self.url_params + self.query_params + self.headers
        if self.body:
            def_params.insert(0, TsParameter(name='body', gen_name='body', type=self.body))

        return def_params

    def get_required_imports(self):
        imports = set()

        if isinstance(self.return_type, TsInterface):
            imports.add(self.return_type)

        if isinstance(self.body, TsInterface):
            imports.add(self.body)

        return imports


class AngularService:
    """
    Class corresponding Angular Service class, used for generation
    """

    def __init__(self, name: str, methods: List[AngularMethod]):
        self.methods = methods
        self.name = self.normalize_name(name)
        self.filename_no_extension = to_spinalcase(self.name[:-len('Service')]) + '.service'

    @staticmethod
    def normalize_name(name):
        if not name.endswith('Service'):
            name = name + 'Service'

        return name

    def get_required_imports(self) -> Set[TsInterface]:
        imports = set()

        for method in self.methods:
            imports = imports.union(method.get_required_imports())

        return imports


class AngularEngine(Engine):
    """
    Angular specific generation engine
    """

    def __init__(self, generation_path=None):
        super().__init__(generation_path, 'angular')
        self.services = []
        self.dto_to_interface = dict()
        self.visitor = TsVisitor(self.dto_to_interface)

    def prepare(self, base_url, endpoints: List[Endpoint]):
        service_name_to_methods = dict()

        for endpoint in endpoints:
            curr_endpoint_body = None
            if endpoint.return_type is not None:
                curr_endpoint_return_type = self.visitor.visit(endpoint.return_type)
            else:
                curr_endpoint_return_type = TsAny()
            if endpoint.body is not None:
                curr_endpoint_body = self.visitor.visit(endpoint.body)

            current_method = AngularMethod(url=adapt_ts_url(base_url, endpoint.url, endpoint.url_params),
                                           method=endpoint.method,
                                           url_params=[TsParameter.from_parameter(url_param) for url_param in
                                                       endpoint.url_params],
                                           query_params=[TsParameter.from_parameter(query_param) for query_param in
                                                         endpoint.query_params],
                                           headers=[TsParameter.from_parameter(header) for header in
                                                    endpoint.headers],
                                           body=curr_endpoint_body,
                                           return_type=curr_endpoint_return_type,
                                           name=endpoint.name)

            service_name_to_methods.setdefault(endpoint.group_name, []).append(current_method)

        for service_name, methods in service_name_to_methods.items():
            self.services.append(AngularService(service_name[0].capitalize() + service_name[1:], methods))

    def generate(self):
        gen_files = []

        for interface in self.dto_to_interface.values():
            gen_files.append(
                GeneratedFile(self.generation_path + '/interfaces/' + interface.filename_no_extension + '.ts',
                              jinja_env.get_template('angular/interface.ts.jinja2').render(interface=interface)))

        for service in self.services:
            gen_files.append(GeneratedFile(self.generation_path + '/services/' + service.filename_no_extension + '.ts',
                                           jinja_env.get_template('angular/service.ts.jinja2').render(service=service)))

        gen_files.append(GeneratedFile(os.path.join(self.generation_path, 'deserializers.ts'),
                                       jinja_env.get_template('fetchapi/deserializers.js.jinja2').render(
                                           interfaces=self.dto_to_interface.values(), ts_enabled=True)))

        return gen_files
