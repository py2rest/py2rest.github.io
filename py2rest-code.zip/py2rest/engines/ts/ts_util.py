import re


def adapt_ts_url(base_url, url, url_params):
    """
    somebaseurl.com/article/{id} , [Parameter(name='id', generated_name='genid'...)])
    -> somebaseurl.com/article/${genid}
    """
    ts_url = url
    for match in re.finditer(r'\{.+?\}', url):
        url_param_name = match.group(0)[1:-1]
        generated_url_param_variable_name = [p for p in url_params if p.name == url_param_name][0].gen_name
        ts_url = ts_url.replace(match.group(0), '${{{}}}'.format(generated_url_param_variable_name))

    return base_url + ts_url
