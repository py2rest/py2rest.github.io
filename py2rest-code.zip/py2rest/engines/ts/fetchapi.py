import os
from typing import List

from py2rest.endpoint import Endpoint
from py2rest.engines.ts.angular import TsParameter
from py2rest.engines.ts.ts_util import adapt_ts_url
from py2rest.engines.ts.ts_visitor import TsVisitor
from py2rest.engines.config import jinja_env
from py2rest.engines.engine import Engine
from py2rest.engines.generated_file import GeneratedFile
from py2rest.util import to_spinalcase


class JSFunction:
    """
    Class describing simple JS function
    """

    def __init__(self, url, method, url_params, query_params, headers, body, return_type, name):
        self.name = name
        self.body = body
        self.url_params = url_params
        self.headers = headers
        self.url = url
        self.method = method
        self.query_params = query_params
        self.return_type = return_type

    def get_all_parameters(self):
        def_params = self.url_params + self.query_params + self.headers
        if self.body:
            def_params.insert(0, TsParameter(name='body', gen_name='body', type=self.body))

        return def_params


class FetchApiEngine(Engine):
    """
    Fetch API generation engine
    """

    def __init__(self, generation_path=None):
        super().__init__(generation_path, 'fetch')
        self.dto_to_interface = dict()
        self.file_name_to_functions = dict()
        self.visitor = TsVisitor(self.dto_to_interface)

    def prepare(self, base_url, endpoints: List[Endpoint]):

        for endpoint in endpoints:
            curr_endpoint_body = None
            curr_endpoint_return_type = None
            if endpoint.body is not None:
                curr_endpoint_body = self.visitor.visit(endpoint.body)
            if endpoint.return_type is not None:
                curr_endpoint_return_type = self.visitor.visit(endpoint.return_type)

            func = JSFunction(url=adapt_ts_url(base_url, endpoint.url, endpoint.url_params), method=endpoint.method,
                              url_params=[TsParameter.from_parameter(url_param) for url_param in
                                          endpoint.url_params],
                              query_params=[TsParameter.from_parameter(query_param) for query_param in
                                            endpoint.query_params],
                              headers=[TsParameter.from_parameter(header) for header in
                                       endpoint.headers],
                              body=curr_endpoint_body,
                              name=endpoint.name,
                              return_type=curr_endpoint_return_type)

            self.file_name_to_functions.setdefault(endpoint.group_name, []).append(func)

    def generate(self):
        files = [GeneratedFile(os.path.join(self.generation_path, to_spinalcase(filename)) + '.js',
                              jinja_env.get_template('fetchapi/fetch.js.jinja2').render(functions=functions))
                for filename, functions in self.file_name_to_functions.items()]
        files.append(GeneratedFile(os.path.join(self.generation_path, 'deserializers.js'),
                                   jinja_env.get_template('fetchapi/deserializers.js.jinja2').render(interfaces=self.dto_to_interface.values())))
        return files
