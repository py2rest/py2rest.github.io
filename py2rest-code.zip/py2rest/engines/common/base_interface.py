from abc import ABC, abstractmethod


class BaseInterface(ABC):

    @abstractmethod
    def __init__(self, identifier, dto_type):
        pass

    @abstractmethod
    def add_field(self, name: str, type):
        pass
