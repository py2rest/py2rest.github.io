from abc import ABC, abstractmethod
from typing import Type

from py2rest.api.fields import ListField, CharField, IntegerField, DecimalField, FloatField, DateTimeField, DateField, \
    BooleanField, FileUploadField, Dto, FormData, AnyField
from py2rest.engines.common.base_interface import BaseInterface


class FieldVisitor(ABC):
    """
    Base py2rest data structure field visitor, implemented by each generation engine to convert generic JSON structure
    to specific language class, i.e. angular interface
    """

    @abstractmethod
    def visit_list_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_char_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_integer_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_decimal_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_float_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_datetime_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_date_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_boolean_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_jsonobject(self, name: str, field):
        pass

    @abstractmethod
    def visit_formdata(self, name: str, field):
        pass

    @abstractmethod
    def visit_file_upload_field(self, name: str, field):
        pass

    @abstractmethod
    def visit_any_field(self, name: str, field):
        pass


class DefaultVisitor(FieldVisitor):
    """
    Usually all engine needs to do to convert generic JSON description to its specific use is map generic fields like
    integer to language specific fields, i.e. in python 'int', in javascript 'number'.
    This class accepts engine specific type mapping and allows engines to easily implement this default behavior.
    It assumes that same structure is used to describe formdata and json and distinguishes them via dto_type string
    used in constructor (the structure implements BaseInterface).
    """

    def __init__(self, field_to_type, interface_class: Type[BaseInterface], dto_to_class: dict):
        self.dto_type = None
        self.main_type = None
        self.current_interface = None
        self.dto_to_class = dto_to_class
        self.field_to_type = field_to_type
        self.interface_class = interface_class

    def visit_list_field(self, name: str, field: ListField):
        if self.dto_type == 'FormData':
            raise AssertionError('Cannot set list in FormData')

        if isinstance(field.element_type, FormData):
            raise AssertionError('Cannot nest FormData in a list')

        unparsed_list_stack = [field]
        current_type = field.element_type

        while isinstance(current_type, ListField):
            unparsed_list_stack.append(current_type)
            current_type = current_type.element_type

        if isinstance(current_type, Dto):
            self.parse_interface(None, current_type, self.dto_type, parsing_array_element=True)
            last_element = self.dto_to_class[current_type.__class__]
        else:
            last_element = self.field_to_type[current_type.__class__](current_type.required, current_type.description,
                                                                      current_type.args, current_type.kwargs)

        current_list_stack_el = None
        while len(unparsed_list_stack) > 0:
            current_list_stack_el = unparsed_list_stack.pop()
            current_list_stack_el = self.field_to_type[current_list_stack_el.__class__](last_element,
                                                                                        current_list_stack_el.required,
                                                                                        current_list_stack_el.description,
                                                                                        *current_list_stack_el.args,
                                                                                        **current_list_stack_el.kwargs)
            last_element = current_list_stack_el

        self.add_field(name, current_list_stack_el)

    def visit_char_field(self, name: str, field: CharField):
        self.add_field(name, self.field_to_type[CharField](field.required, field.description, *field.args, **field.kwargs))

    def visit_integer_field(self, name: str, field: IntegerField):
        self.add_field(name, self.field_to_type[IntegerField](field.required, field.description, *field.args, **field.kwargs))

    def visit_decimal_field(self, name: str, field: DecimalField):
        self.add_field(name, self.field_to_type[DecimalField](field.required, field.description, *field.args, **field.kwargs))

    def visit_float_field(self, name: str, field: FloatField):
        self.add_field(name, self.field_to_type[FloatField](field.required, field.description, *field.args, **field.kwargs))

    def visit_datetime_field(self, name: str, field: DateTimeField):
        self.add_field(name, self.field_to_type[DateTimeField](field.required, field.description, *field.args, **field.kwargs))

    def visit_date_field(self, name: str, field: DateField):
        self.add_field(name, self.field_to_type[DateField](field.required, field.description, *field.args, **field.kwargs))

    def visit_boolean_field(self, name: str, field: BooleanField):
        self.add_field(name, self.field_to_type[BooleanField](field.required, field.description, *field.args, **field.kwargs))

    def visit_file_upload_field(self, name: str, field: FileUploadField):
        if self.dto_type != 'FormData':
            raise AssertionError('Can only set file upload field in FormData')
        self.add_field(name, self.field_to_type[FileUploadField](field.required, field.description, *field.args, **field.kwargs))

    def visit_any_field(self, name: str, field):
        self.add_field(name, self.field_to_type[AnyField](field.required, field.description, *field.args, **field.kwargs))

    def visit_jsonobject(self, name: str, dto: Dto):
        if self.dto_type == 'FormData':
            raise AssertionError('Cannot nest JSONObject in FormData')
        self.dto_type = 'JSONObject'
        self.parse_interface(name, dto, 'JSONObject')

    def visit_formdata(self, name: str, dto: Dto):
        if self.dto_type is not None:
            raise AssertionError('Cannot nest objects in FormData')
        self.dto_type = 'FormData'
        self.parse_interface(name, dto, 'FormData')

    def parse_interface(self, name, dto, dto_type, parsing_array_element=False):
        interface = self.dto_to_class.get(dto.__class__, self.interface_class(dto.__class__.__name__, dto_type,
                                                                              dto.required, dto.description))
        is_main_type = False

        if self.main_type is None and not parsing_array_element:
            is_main_type = True
            self.main_type = self.current_interface = interface

        if not interface.is_already_parsed:
            interface.is_already_parsed = True
            self.dto_to_class[dto.__class__] = interface
            saved_interface = self.current_interface

            self.current_interface = interface
            for fieldname, field in dto.get_fields():
                field.accept(fieldname, self)

            self.current_interface = saved_interface

        if not is_main_type and not parsing_array_element:
            self.current_interface.add_field(name, interface)

    def add_field(self, name: str, type):
        if self.main_type is None:
            self.main_type = type
        else:
            self.current_interface.add_field(name, type)

    def visit(self, field):
        self.main_type = None
        self.current_interface = None
        self.dto_type = None
        field.accept(None, self)

        return self.main_type
