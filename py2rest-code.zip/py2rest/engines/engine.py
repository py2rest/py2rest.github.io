import os
import sys
from abc import ABC, abstractmethod


class Engine(ABC):
    """
    Abstract generation engine used by Py2Rest class to generate specific code based on endpoint documentation.
    """

    def __init__(self, generation_path, default_directory):
        if generation_path is None:
            generation_path = os.path.join(os.path.dirname(os.path.abspath(sys.modules['__main__'].__file__)),
                                           'gen', default_directory)
        self.generation_path = generation_path

    @abstractmethod
    def prepare(self, base_url, endpoints):
        pass

    @abstractmethod
    def generate(self):
        pass

