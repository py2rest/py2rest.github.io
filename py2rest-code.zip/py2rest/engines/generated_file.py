
class GeneratedFile:
    """
    Generalization of file with path and some contents. This object is returned from generation engines so it can
    possibly be intercepted before being written to filesystem.
    """

    def __init__(self, path: str, contents: str):
        self.path = path
        self.contents = contents
