from datetime import date, datetime
from typing import List

from py2rest.endpoint import Endpoint
from py2rest.engines.config import jinja_env
from py2rest.engines.engine import Engine
from py2rest.engines.generated_file import GeneratedFile
from py2rest.engines.openapi.openapi_types import OpenAPIInteger, OpenAPIBoolean, OpenAPIDate, OpenAPIDateTime, \
    OpenAPIFloat, OpenAPIString, OpenAPIType, OpenAPIAny
from py2rest.engines.openapi.openapi_visitor import OpenAPIVisitor
from py2rest.http_method import HttpMethod

PYTHON_TO_OPEN_API_TYPE = {
    int: OpenAPIInteger(),
    bool: OpenAPIBoolean(),
    date: OpenAPIDate(),
    datetime: OpenAPIDateTime(),
    float: OpenAPIFloat(),
    str: OpenAPIString(),
    None: OpenAPIString()
}


class OpenAPIParameter:
    """
    Helper class used to identify OpenAPI parameter
    """

    def __init__(self, name: str, gen_name: str, type: OpenAPIType, required, description):
        self.name = name
        self.gen_name = gen_name
        self.type = type
        self.required = required
        self.description = description

    @classmethod
    def from_parameter(cls, parameter):
        return cls(parameter.name, parameter.gen_name, PYTHON_TO_OPEN_API_TYPE[parameter.type],
                   parameter.required, parameter.description)


class OpenAPIMethod:
    """
    Helper class used to identify OpenAPI endpoint
    """

    def __init__(self, method: HttpMethod, url_params: List[OpenAPIParameter], query_params: List[OpenAPIParameter],
                 headers: List[OpenAPIParameter], body: OpenAPIType, return_type: OpenAPIType, name: str):
        self.url_params = url_params
        self.name = name
        self.body = body
        self.headers = headers
        self.method = method
        self.query_params = query_params
        self.return_type = return_type
        self.body_is_any = isinstance(body, OpenAPIAny)


class OpenAPIPath:
    """
    Helper class used to identify url used in OpenAPI description
    """

    def __init__(self, url: str):
        self.url = url
        self.methods = []

    def add_method(self, method: OpenAPIMethod):
        self.methods.append(method)


class OpenAPIEngine(Engine):
    """
    OpenAPI generation engine, responsible for proper type mapping and generation.
    """

    def __init__(self, generation_path=None, title='Py2Rest generated OpenAPI'):
        super().__init__(generation_path, 'openAPI')
        self.title = title
        self.paths = []
        self.schemas = []
        self.server_url = None
        self.dto_to_interface = dict()
        self.visitor = OpenAPIVisitor(self.dto_to_interface)

    def prepare(self, base_url, endpoints: List[Endpoint]):
        url_to_openapi_path = dict()

        self.server_url = base_url

        for endpoint in endpoints:
            curr_endpoint_body = None
            if endpoint.return_type is not None:
                curr_endpoint_return_type = self.visitor.visit(endpoint.return_type)
            else:
                curr_endpoint_return_type = None
            if endpoint.body is not None:
                curr_endpoint_body = self.visitor.visit(endpoint.body)

            current_method = OpenAPIMethod(method=endpoint.method,
                                           url_params=[OpenAPIParameter.from_parameter(url_param) for url_param in
                                                       endpoint.url_params],
                                           query_params=[OpenAPIParameter.from_parameter(query_param) for query_param in
                                                         endpoint.query_params],
                                           headers=[OpenAPIParameter.from_parameter(header) for header in
                                                    endpoint.headers],
                                           body=curr_endpoint_body,
                                           return_type=curr_endpoint_return_type,
                                           name=endpoint.name)

            url_to_openapi_path.setdefault(endpoint.url, OpenAPIPath(endpoint.url)).add_method(current_method)

        for path in url_to_openapi_path.values():
            self.paths.append(path)

        for schema in self.dto_to_interface.values():
            self.schemas.append(schema)

    def generate(self):
        return [GeneratedFile(self.generation_path + '/openapi.yaml',
                              jinja_env.get_template('openapi/openapi.yaml.jinja2').render(server_url=self.server_url,
                                                                                           paths=self.paths,
                                                                                           title=self.title,
                                                                                           schemas=self.schemas))]
