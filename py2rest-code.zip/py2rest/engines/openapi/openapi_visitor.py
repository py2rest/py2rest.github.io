from py2rest.api.fields import ListField, CharField, IntegerField, DecimalField, FloatField, DateTimeField, DateField, \
    BooleanField, FileUploadField, AnyField
from py2rest.engines.common.visitor import DefaultVisitor
from py2rest.engines.openapi.openapi_types import OpenAPIArray, OpenAPIString, OpenAPIInteger, OpenAPIDecimal, \
    OpenAPIFloat, OpenAPIBoolean, OpenAPIFile, OpenAPIObject, OpenAPIDate, OpenAPIDateTime, OpenAPIAny


class OpenAPIVisitor(DefaultVisitor):

    FIELD_TO_TYPE = {
        ListField: OpenAPIArray,
        CharField: OpenAPIString,
        IntegerField: OpenAPIInteger,
        DecimalField: OpenAPIDecimal,
        FloatField: OpenAPIFloat,
        DateTimeField: OpenAPIDateTime,
        DateField: OpenAPIDate,
        BooleanField: OpenAPIBoolean,
        FileUploadField: OpenAPIFile,
        AnyField: OpenAPIAny
    }

    def __init__(self, dto_to_interface: dict):
        super().__init__(OpenAPIVisitor.FIELD_TO_TYPE, OpenAPIObject, dto_to_interface)
