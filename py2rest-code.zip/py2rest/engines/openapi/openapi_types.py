from py2rest.engines.common.base_interface import BaseInterface
from py2rest.engines.config import jinja_env

# This module contains classes corresponding to OpenAPI specific types


class OpenAPIType:
    """
    Base OpenAPI field type used during generation
    """

    def __init__(self, identifier, required=False, description='', *args, **kwargs):
        self.identifier = identifier
        self.required = required
        self.description = description
        self.args = args
        self.kwargs = kwargs


class OpenAPIField:

    def __init__(self, name: str, type: OpenAPIType):
        self.name = name
        self.type = type


class OpenAPIString(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('string', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: string'


class OpenAPIInteger(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('integer', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: integer'


class OpenAPIFloat(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('float', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: number'


class OpenAPIBoolean(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('boolean', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: boolean'


class OpenAPIArray(OpenAPIType):

    def __init__(self, element_type: OpenAPIType, required=False, description='', *args, **kwargs):
        super().__init__('array', required, description, *args, **kwargs)
        self.element_type = element_type

    def get_schema_ref(self):
        return jinja_env.get_template('openapi/openapi_schema_array.yaml.jinja2').render(element_type=self.element_type)


class OpenAPIObject(OpenAPIType, BaseInterface):

    def __init__(self, identifier, dto_type, required, description, *args, **kwargs):
        super().__init__(identifier, required, description, *args, **kwargs)
        self.identifier = identifier
        self.dto_type = dto_type
        self.is_already_parsed = False
        self.fields = []

    def add_field(self, name: str, type: OpenAPIType):
        self.fields.append(OpenAPIField(name, type))

    def get_schema_definition(self):
        return jinja_env.get_template('openapi/openapi_schema_def.yaml.jinja2').render(identifier=self.identifier,
                                                                                       fields=self.fields)

    def get_schema_ref(self):
        return '$ref: \'#/components/schemas/{}\''.format(self.identifier)


class OpenAPIFile(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('file', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: string\nformat: binary'


class OpenAPIDecimal(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('decimal', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: number\nformat: decimal'


class OpenAPIDate(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('date', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: string\nformat: date'


class OpenAPIDateTime(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('date-time', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: string\nformat: date-time'


class OpenAPIAny(OpenAPIType):

    def __init__(self, required=False, description='', *args, **kwargs):
        super().__init__('any', required, description, *args, **kwargs)

    def get_schema_ref(self):
        return 'type: string'
