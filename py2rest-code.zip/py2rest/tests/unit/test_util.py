from unittest import TestCase

from py2rest.api.parameter import Parameter
from py2rest.engines.ts.ts_util import adapt_ts_url
from py2rest.util import to_spinalcase, to_snakecase, escape_forbidden_variable_name_symbols, module_qualified_name


class UtilTestCase(TestCase):

    def test_adapt_ts_url(self):
        ts_url = adapt_ts_url('localhost:8080', '/test/{param1}/{param2}',
                              [Parameter(name='param1', type=int, gen_name='gen_param1'),
                               Parameter(name='param2', type=int, gen_name='gen_param2')])

        expected_url = 'localhost:8080/test/${gen_param1}/${gen_param2}'

        self.assertEqual(expected_url, ts_url)

    def test_to_spinalcase(self):
        camel = 'camelCase'
        expected = 'camel-case'

        self.assertEqual(expected, to_spinalcase(camel))

    def test_to_snakecase(self):
        camel = 'camelCase'
        expected = 'camel_case'

        self.assertEqual(expected, to_snakecase(camel))

    def test_escape_forbidden_variable_name_symbols(self):
        bad_name = '1fix#me13'
        expected = '_fix_me13'

        self.assertEqual(expected, escape_forbidden_variable_name_symbols(bad_name))

    def test_module_qualified_name(self):
        class TestObj:
            pass

        self.assertEqual('py2rest.tests.unit.test_util.TestObj', module_qualified_name(TestObj))
