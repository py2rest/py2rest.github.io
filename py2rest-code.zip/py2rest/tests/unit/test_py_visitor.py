from unittest import TestCase

from py2rest.api.fields import BooleanField, DateField, IntegerField, CharField, JSONObject
from py2rest.engines.python.py_types import PyDict, PyBool, PyDate
from py2rest.engines.python.py_visitor import PyVisitor


class FlatDto(JSONObject):
    test_bool = BooleanField()
    test_date = DateField()


class NestedDto1(JSONObject):
    test_int = IntegerField()


class NestedDto2(JSONObject):
    test_nested1 = NestedDto1()


NestedDto1.test_nested2 = NestedDto2()


class NestedDto3(JSONObject):
    test_str = CharField()


NestedDto3.test_nested3 = NestedDto3()


class PyVisitorTestCase(TestCase):

    def setUp(self):
        dto_to_interface = dict()
        self.visitor = PyVisitor(dto_to_interface)

    def test_visits_flat_dto_corectly(self):

        self.visitor.visit(FlatDto())
        self.assertIsInstance(self.visitor.main_type, PyDict)
        self.assertEqual(len(self.visitor.main_type.py_fields), 2)
        self.assertEqual(self.visitor.main_type.py_fields[0].name, 'test_bool')
        self.assertIsInstance(self.visitor.main_type.py_fields[0].type, PyBool)
        self.assertEqual(self.visitor.main_type.py_fields[1].name, 'test_date')
        self.assertIsInstance(self.visitor.main_type.py_fields[1].type, PyDate)

    def test_visits_nested_circular_dto_correctly(self):
        self.visitor.visit(NestedDto1())
        self.assertIsInstance(self.visitor.main_type, PyDict)
        self.assertEqual(len(self.visitor.main_type.py_fields), 2)

    def test_visits_self_nested_dto_correctly(self):
        self.visitor.visit(NestedDto3())
        self.assertEqual(len(self.visitor.main_type.py_fields), 2)
