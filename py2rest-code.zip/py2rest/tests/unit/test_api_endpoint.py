from unittest import TestCase

from py2rest import http_method
from py2rest.api.parameter import Parameter
from py2rest.api_endpoint import api_endpoint_registry, api_endpoint


class ApiEndpointTestCase(TestCase):

    def setUp(self):
        api_endpoint_registry.clear()

    def test_registers_controller(self):

        @api_endpoint('/testurl/{id}', http_method.GET, [Parameter('id', int)], [Parameter('page', int)],
                      [Parameter('custom-header', str)])
        def controller():
            pass

        self.assertEqual(len(api_endpoint_registry), 1)
        self.assertEqual(api_endpoint_registry[0].query_params[0].name, 'page')
        self.assertEqual(api_endpoint_registry[0].url_params[0].name, 'id')
        self.assertEqual(api_endpoint_registry[0].headers[0].name, 'custom-header')
