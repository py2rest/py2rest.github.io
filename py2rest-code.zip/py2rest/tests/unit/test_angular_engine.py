from unittest import TestCase

import py2rest.http_method
from py2rest.api.fields import IntegerField, FloatField, CharField, DateTimeField, JSONObject, FileUploadField, \
    FormData
from py2rest.api.parameter import Parameter
from py2rest.endpoint import Endpoint
from py2rest.engines.ts.angular import AngularEngine


class TestReturnType(JSONObject):
    test_int = IntegerField()
    test_float = FloatField()


class TestBody(JSONObject):
    test_str = CharField()
    test_datetime = DateTimeField()


class TestBodyFormData(FormData):
    test_str = CharField()
    test_file = FileUploadField()


class AngularEngineTestCase(TestCase):

    def setUp(self):
        self.engine = AngularEngine()

    def test_prepares_correctly(self):
        endpoint1 = Endpoint(controller=None,
                             url='/test1/{xx}',
                             url_params=[Parameter(name='xx', type=int, gen_name='generatedXx')],
                             query_params=[Parameter(name='test_bool', type=bool)],
                             headers=None,
                             return_type=TestReturnType(),
                             method=py2rest.http_method.GET,
                             group_name='MyService',
                             name='getEndpoint1')

        endpoint2 = Endpoint(controller=None,
                             url='/test2',
                             url_params=[],
                             query_params=[],
                             headers=[Parameter(name='test_header', type=str)],
                             body=TestBody(),
                             return_type=TestReturnType(),
                             method=py2rest.http_method.POST,
                             group_name='MyService',
                             name='postEndpoint2')

        endpoint3 = Endpoint(controller=None,
                             url='/test/test3',
                             method=py2rest.http_method.GET,
                             group_name='OtherService',
                             name='getEndpoint3')

        endpoint4 = Endpoint(controller=None,
                             url='/test/test4',
                             method=py2rest.http_method.POST,
                             group_name='FileService',
                             name='postEndpoint4',
                             body=TestBodyFormData())

        self.engine.prepare('localhost:8000', [endpoint1, endpoint2, endpoint3, endpoint4])
        self.assertEqual(len(self.engine.services), 3)
        my_service = self.engine.services[0] if self.engine.services[0].name == 'MyService' else self.engine.services[1]
        other_service = self.engine.services[1] if my_service == self.engine.services[0] else self.engine.services[0]
        file_service = [svc for svc in self.engine.services if svc.name == 'FileService'][0]
        self.assertEqual(my_service.methods[0].name, 'getEndpoint1')
        self.assertEqual(my_service.methods[1].name, 'postEndpoint2')
        self.assertEqual(other_service.methods[0].name, 'getEndpoint3')
        self.assertEqual(file_service.methods[0].name, 'postEndpoint4')
