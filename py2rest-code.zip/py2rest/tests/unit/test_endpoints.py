from unittest import TestCase

from py2rest import http_method
from py2rest.api.fields import AnyField
from py2rest.api.parameter import Parameter
from py2rest.endpoint import Endpoint
from py2rest.errors import Py2RestConfigError


class EndpointTestCase(TestCase):

    def test_pre_validates_correct_url_true(self):
        endpoint = Endpoint(controller=None,
                            method=http_method.GET,
                            url='/{first}/test/{second}',
                            url_params=[Parameter('first', int), Parameter('second', str)],
                            name='tstendpoint')

        self.assertTrue(endpoint.pre_validate())

    def test_pre_validates_none_url_true(self):
        endpoint = Endpoint(controller=None,
                            method=http_method.GET,
                            url=None,
                            name='tstendpoint')

        self.assertTrue(endpoint.pre_validate())

    def test_pre_validates_invalid_url_false(self):
        endpoint = Endpoint(controller=None,
                            method=http_method.GET,
                            url='/{first}/test/{second}',
                            url_params=[Parameter('first', int), Parameter('third', str)],
                            name='tstendpoint')

        self.assertFalse(endpoint.pre_validate())

    def test_invalid_url_params(self):
        self.assertRaises(Py2RestConfigError, Endpoint,
                          controller=None,
                          method=http_method.GET,
                          url='/{first}/test/{second}',
                          url_params=[Parameter('first', int), 'invalid'],
                          name='test_endpoint'
                          )

    def test_invalid_query_params(self):
        self.assertRaises(Py2RestConfigError, Endpoint,
                          controller=None,
                          method=http_method.GET,
                          url='/{first}/test/{second}',
                          url_params=[Parameter('first', int), Parameter('third', str)],
                          query_params=[Parameter('page', int), str],
                          name='test_endpoint'
                          )

    def test_invalid_headers(self):
        self.assertRaises(Py2RestConfigError, Endpoint,
                          controller=None,
                          method=http_method.GET,
                          url='/{first}/test/{second}',
                          url_params=[Parameter('first', int), Parameter('third', str)],
                          query_params=[Parameter('page', int)],
                          headers=str,
                          name='test_endpoint'
                          )

    def test_invalid_method(self):
        self.assertRaises(Py2RestConfigError, Endpoint,
                          controller=None,
                          method='GET',
                          url='/{first}/test/{second}',
                          url_params=[Parameter('first', int), Parameter('second', int)],
                          name='test_endpoint'
                          )

    def test_invalid_body(self):
        self.assertRaises(Py2RestConfigError, Endpoint,
                          controller=None,
                          method=http_method.GET,
                          url='/{first}/test/{second}',
                          url_params=[Parameter('first', int), Parameter('second', int)],
                          body='invalid',
                          name='test_endpoint'
                          )

    def test_invalid_return_type(self):
        self.assertRaises(Py2RestConfigError, Endpoint,
                          controller=None,
                          method=http_method.GET,
                          url='/{first}/test/{second}',
                          url_params=[Parameter('first', int), Parameter('second', int)],
                          return_type='invalid',
                          name='test_endpoint'
                          )

    def test_valid_endpoint(self):
        Endpoint(controller=None,
                 method=http_method.GET,
                 url='/{first}/test/{second}',
                 url_params=[Parameter('first', int), Parameter('second', int)],
                 return_type=AnyField(),
                 name='test_endpoint')
