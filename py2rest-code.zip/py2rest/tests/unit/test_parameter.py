import datetime
from unittest import TestCase

from py2rest.api.parameter import Parameter
from py2rest.errors import Py2RestConfigError


class ParameterTestCase(TestCase):

    def test_parameter_invalid_name(self):
        self.assertRaises(Py2RestConfigError, Parameter, name=4, type=int, required=False, description='')

    def test_parameter_invalid_type(self):
        self.assertRaises(Py2RestConfigError, Parameter, name='param1', type='int', required=False, description='')

    def test_parameter_invalid_required(self):
        self.assertRaises(Py2RestConfigError, Parameter, name='param1', type=datetime.date, required='a', description='')

    def test_parameter_invalid_description(self):
        self.assertRaises(Py2RestConfigError, Parameter, name='param1', type=datetime.date, required=True,
                          description=set())

    def test_parameter_invalid_gen_name(self):
        self.assertRaises(Py2RestConfigError, Parameter, name='param1', type=datetime.date, required=True,
                          description='descr', gen_name=datetime.datetime)

    def test_correct_parameter(self):
        Parameter(name='param1', type=datetime.date, required=True, description='descr', gen_name='generatedName')
