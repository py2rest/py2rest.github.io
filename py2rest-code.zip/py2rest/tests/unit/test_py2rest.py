from unittest import TestCase

from py2rest import api_endpoint, http_method
from py2rest.api.parameter import Parameter
from py2rest.endpoint import Endpoint
from py2rest.errors import Py2RestConfigError
from py2rest.py2rest_gen import Py2Rest


class Py2RestTestCase(TestCase):

    def test_read_annotated_endpoints(self):
        endpoint = Endpoint(controller=None,
                            method=http_method.GET,
                            url='/{first}/test/{second}',
                            url_params=[Parameter('first', int), Parameter('second', str)],
                            name='tstendpoint')

        api_endpoint.api_endpoint_registry = [endpoint]

        py2rest = Py2Rest('localhost:1234', engines=[])

        py2rest.read_decorated_endpoints()

        self.assertEqual(len(py2rest.endpoints), 1)
        self.assertEqual(py2rest.endpoints[0], endpoint)

    def test_duplicate_group_name_endpoints(self):
        endpoint1 = Endpoint(controller=None,
                             method=http_method.GET,
                             url='/first',
                             name='duplicatedname')

        endpoint2 = Endpoint(controller=None,
                             method=http_method.GET,
                             url='/duplicated',
                             url_params=[Parameter('first', int), Parameter('second', str)],
                             name='duplicatedname')

        api_endpoint.api_endpoint_registry = [endpoint1, endpoint2]

        py2rest = Py2Rest('localhost:1234', engines=[])

        py2rest.read_decorated_endpoints()

        self.assertRaises(Py2RestConfigError, py2rest.generate)
