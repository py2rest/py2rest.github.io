from unittest import TestCase

from py2rest.api.fields import CharField, JSONObject, IntegerField, ListField, DecimalField, FloatField, DateTimeField, \
    DateField, BooleanField, FormData, FileUploadField, AnyField
from py2rest.engines.common.visitor import FieldVisitor
from py2rest.errors import Py2RestConfigError


class StubVisitor(FieldVisitor):

    def __init__(self):
        self.visited_field = None

    def visit_list_field(self, name: str, field):
        self.visited_field = 'list'

    def visit_char_field(self, name: str, field):
        self.visited_field = 'char'

    def visit_integer_field(self, name: str, field):
        self.visited_field = 'int'

    def visit_decimal_field(self, name: str, field):
        self.visited_field = 'decimal'

    def visit_float_field(self, name: str, field):
        self.visited_field = 'float'

    def visit_datetime_field(self, name: str, field):
        self.visited_field = 'datetime'

    def visit_date_field(self, name: str, field):
        self.visited_field = 'date'

    def visit_boolean_field(self, name: str, field):
        self.visited_field = 'bool'

    def visit_jsonobject(self, name: str, field):
        self.visited_field = 'json'

    def visit_formdata(self, name: str, field):
        self.visited_field = 'formdata'

    def visit_file_upload_field(self, name: str, field):
        self.visited_field = 'file'

    def visit_any_field(self, name: str, field):
        self.visited_field = 'any'


class FieldTestCase(TestCase):

    def setUp(self):
        self.visitor = StubVisitor()

    def test_invalid_required(self):
        self.assertRaises(Py2RestConfigError, CharField, required=str, description='descr')

    def test_invalid_description(self):
        self.assertRaises(Py2RestConfigError, CharField, required=True, description=False)

    def test_valid_field(self):
        CharField(required=True, description='descr')

    def test_list_field_bad_element_type(self):
        self.assertRaises(Py2RestConfigError, ListField, element_type='bad')

    def test_dto_get_fields_ignores_nonfield_properties(self):
        class MyJson(JSONObject):
            random_field = 3
            my_int_field = IntegerField()
            my_char_field = CharField()

        self.assertEqual(2, len(MyJson.get_fields()))
        self.assertEqual('my_int_field', MyJson.get_fields()[0][0])
        self.assertEqual(MyJson.my_int_field, MyJson.get_fields()[0][1])
        self.assertEqual('my_char_field', MyJson.get_fields()[1][0])
        self.assertEqual(MyJson.my_char_field, MyJson.get_fields()[1][1])

    def test_accept_list_field(self):
        ListField(CharField()).accept('', self.visitor)
        self.assertEqual('list', self.visitor.visited_field)

    def test_accept_char_field(self):
        CharField().accept('', self.visitor)
        self.assertEqual('char', self.visitor.visited_field)

    def test_accept_integer_field(self):
        IntegerField().accept('', self.visitor)
        self.assertEqual('int', self.visitor.visited_field)

    def test_accept_decimal_field(self):
        DecimalField().accept('', self.visitor)
        self.assertEqual('decimal', self.visitor.visited_field)

    def test_accept_float_field(self):
        FloatField().accept('', self.visitor)
        self.assertEqual('float', self.visitor.visited_field)

    def test_accept_datetime_field(self):
        DateTimeField().accept('', self.visitor)
        self.assertEqual('datetime', self.visitor.visited_field)

    def test_accept_date_field(self):
        DateField().accept('', self.visitor)
        self.assertEqual('date', self.visitor.visited_field)

    def test_accept_boolean_field(self):
        BooleanField().accept('', self.visitor)
        self.assertEqual('bool', self.visitor.visited_field)

    def test_accept_jsonobject(self):
        JSONObject().accept('', self.visitor)
        self.assertEqual('json', self.visitor.visited_field)

    def test_accept_formdata(self):
        FormData().accept('', self.visitor)
        self.assertEqual('formdata', self.visitor.visited_field)

    def test_accept_file_upload_field(self):
        FileUploadField().accept('', self.visitor)
        self.assertEqual('file', self.visitor.visited_field)

    def test_accept_any_field(self):
        AnyField().accept('', self.visitor)
        self.assertEqual('any', self.visitor.visited_field)
