import shutil
from unittest import TestCase

from py2rest.engines.generated_file import GeneratedFile
from py2rest.fileio import FileIO


class UtilTestCase(TestCase):

    def test_file_writing(self):
        try:
            expected_f1_content = 'content 1'
            expected_f2_content = 'content 2'
            gen_files = [GeneratedFile('_test_directory/test_file1', expected_f1_content),
                         GeneratedFile('_test_directory/test_file2', expected_f2_content)]
            FileIO().write_files(gen_files)

            with open('_test_directory/test_file1', 'r') as f1:
                f1_contents = f1.read()

            with open('_test_directory/test_file2', 'r') as f2:
                f2_contents = f2.read()

            self.assertEqual(expected_f1_content, f1_contents)
            self.assertEqual(expected_f2_content, f2_contents)
        finally:
            shutil.rmtree('_test_directory')
