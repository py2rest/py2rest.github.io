from unittest import TestCase

from py2rest.api.fields import BooleanField, DateField, IntegerField, CharField, JSONObject
from py2rest.engines.openapi.openapi_types import OpenAPIObject, OpenAPIBoolean, OpenAPIDate
from py2rest.engines.openapi.openapi_visitor import OpenAPIVisitor


class FlatDto(JSONObject):
    test_bool = BooleanField()
    test_date = DateField()


class NestedDto1(JSONObject):
    test_int = IntegerField()


class NestedDto2(JSONObject):
    test_nested1 = NestedDto1()


NestedDto1.test_nested2 = NestedDto2()


class NestedDto3(JSONObject):
    test_str = CharField()


NestedDto3.test_nested3 = NestedDto3()


class PyVisitorTestCase(TestCase):

    def setUp(self):
        dto_to_interface = dict()
        self.visitor = OpenAPIVisitor(dto_to_interface)

    def test_visits_flat_dto_corectly(self):

        self.visitor.visit(FlatDto())
        self.assertIsInstance(self.visitor.main_type, OpenAPIObject)
        self.assertEqual(len(self.visitor.main_type.fields), 2)
        self.assertEqual(self.visitor.main_type.fields[0].name, 'test_bool')
        self.assertIsInstance(self.visitor.main_type.fields[0].type, OpenAPIBoolean)
        self.assertEqual(self.visitor.main_type.fields[1].name, 'test_date')
        self.assertIsInstance(self.visitor.main_type.fields[1].type, OpenAPIDate)

    def test_visits_nested_circular_dto_correctly(self):
        self.visitor.visit(NestedDto1())
        self.assertIsInstance(self.visitor.main_type, OpenAPIObject)
        self.assertEqual(len(self.visitor.main_type.fields), 2)

    def test_visits_self_nested_dto_correctly(self):
        self.visitor.visit(NestedDto3())
        self.assertEqual(len(self.visitor.main_type.fields), 2)
