from unittest import TestCase

from py2rest.engines.openapi.openapi import OpenAPIEngine
from py2rest.tests.integration.endpoints import simple_endpoint, simple_formdata_endpoint, formdata_with_file_endpoint, \
    simple_get_with_params_endpoint
from py2rest.tests.integration.util import contains_ignore_whitespace


class OpenApiGenerationTestCase(TestCase):

    def setUp(self):
        self.engine = OpenAPIEngine()

    def test_generates_single_json_get_endpoint(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])
        openapi_yaml = self.engine.generate()[0]

        expected_content = '''
        paths:
          /test-url:
            get:
              responses:
                200:
                  description: No description provided
                  content:
                    application/json:
                      schema:
                        $ref: '#/components/schemas/SimpleJsonGet'
        components:
          schemas:
            SimpleJsonGet:
              type: object
              properties:
                simpleInt:
                  type: integer
                simpleDate:
                  type: string
                  format: date
        '''

        self.assertTrue(contains_ignore_whitespace(openapi_yaml.contents, expected_content))

    def test_generates_correct_formdata_endpoint(self):
        self.engine.prepare('localhost:8000', [simple_formdata_endpoint])
        openapi_yaml = self.engine.generate()[0]
        expected_content = '''
        paths:
          /test-url:
            get:
              requestBody:
                required: False
                content:
                  multipart/form-data:
                    schema:
                      $ref: '#/components/schemas/SimpleFormData'
              responses:
                200:
                  description: No description provided
        components:
          schemas:
            SimpleFormData:
              type: object
              properties:
                simpleString:
                  type: string
                simpleFloat:
                  type: number
        '''

        self.assertTrue(contains_ignore_whitespace(openapi_yaml.contents, expected_content))

    def test_generates_correct_formdata_with_files_body(self):
        self.engine.prepare('localhost:8000', [formdata_with_file_endpoint])
        openapi_yaml = self.engine.generate()[0]

        expected_content = '''
        paths:
          /test-url:
            get:
              requestBody:
                required: False
                content:
                  multipart/form-data:
                    schema:
                      $ref: '#/components/schemas/FormDataWithFile'
              responses:
                200:
                  description: No description provided
        components:
          schemas:
            FormDataWithFile:
              type: object
              properties:
                simpleDecimal:
                  type: number
                  format: decimal
                simpleFile:
                  type: string
                  format: binary
        '''
        self.assertTrue(contains_ignore_whitespace(openapi_yaml.contents, expected_content))

    def test_generates_correct_get_with_params(self):
        self.engine.prepare('localhost:8000', [simple_get_with_params_endpoint])
        openapi_yaml = self.engine.generate()[0]

        expected_content = '''
        openapi: "3.0.0"
info:
  version: 1.0.0
  title: Py2Rest generated OpenAPI
servers:
  - url: localhost:8000
paths:
  /test-url/{param1}/{param2}:
    get:
      parameters:
        - name: param1
          in: path
          required: true
          schema:
            type: integer
        - name: param2
          in: path
          required: true
          schema:
            type: string
        - name: query-param1
          in: query
          required: false
          schema:
            type: string
        - name: header1
          in: header
          required: false
          schema:
            type: string
      responses:
        200:
          description: No description provided
        '''

        self.assertTrue(contains_ignore_whitespace(openapi_yaml.contents, expected_content))

