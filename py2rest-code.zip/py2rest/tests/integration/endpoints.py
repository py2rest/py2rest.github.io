from py2rest import http_method
from py2rest.api.fields import DateField, IntegerField, JSONObject, FormData, CharField, FloatField, FileUploadField, \
    DecimalField
from py2rest.api.parameter import Parameter
from py2rest.endpoint import Endpoint


class SimpleJsonGet(JSONObject):
    simpleInt = IntegerField()
    simpleDate = DateField()


class SimpleFormData(FormData):
    simpleString = CharField()
    simpleFloat = FloatField()


class FormDataWithFile(FormData):
    simpleDecimal = DecimalField()
    simpleFile = FileUploadField()


simple_endpoint = Endpoint(controller=None,
                           method=http_method.GET,
                           url='/test-url',
                           group_name='api',
                           name='simple_get_func',
                           return_type=SimpleJsonGet())

simple_formdata_endpoint = Endpoint(controller=None,
                                    method=http_method.GET,
                                    url='/test-url',
                                    group_name='api',
                                    name='simple_get_func',
                                    body=SimpleFormData())

formdata_with_file_endpoint = Endpoint(controller=None,
                                       method=http_method.GET,
                                       url='/test-url',
                                       group_name='api',
                                       name='simple_get_func',
                                       body=FormDataWithFile())

simple_get_with_params_endpoint = Endpoint(controller=None,
                                           method=http_method.GET,
                                           url='/test-url/{param1}/{param2}',
                                           url_params=[Parameter('param1', int), Parameter('param2', str)],
                                           query_params=[Parameter('query-param1', str)],
                                           headers=[Parameter('header1', str)],
                                           name='simple_get_func')
