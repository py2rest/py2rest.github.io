from unittest import TestCase

from py2rest.engines.ts.angular import AngularEngine
from py2rest.tests.integration.endpoints import simple_endpoint, simple_formdata_endpoint, formdata_with_file_endpoint, \
    simple_get_with_params_endpoint
from py2rest.tests.integration.util import contains_ignore_whitespace


class AngularGenerationTestCase(TestCase):

    def setUp(self):
        self.engine = AngularEngine()

    def test_generates_single_json_get(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])

        files = self.engine.generate()

        api_ts = [file for file in files if file.path.endswith('api.service.ts')][0]

        expected_code = '''
        simple_get_func(): Observable<SimpleJsonGet> {
          return this.http.get(`localhost:8000/test-url`,
              { responseType: 'text' }).pipe(map(data => deserializers.deserializeSimpleJsonGet(data)));  }
          }
        '''

        self.assertTrue(contains_ignore_whitespace(api_ts.contents, expected_code))

    def test_generates_interface_single_json_get(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])

        files = self.engine.generate()

        interface_ts = [file for file in files if file.path.endswith('simple-json-get.ts')][0]

        expected_code = '''
        export interface SimpleJsonGet {
          simpleInt?: number;
          simpleDate?: Date;
        }
        '''

        self.assertTrue(contains_ignore_whitespace(interface_ts.contents, expected_code))

    def test_generates_simple_deserializer(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])
        files = self.engine.generate()

        deserializers_ts = [file for file in files if file.path.endswith('deserializers.ts')][0]

        expected_code = '''
        export function deserializeSimpleJsonGet(response_body) {
          var obj = JSON.parse(response_body);
          if (obj.simpleDate) {
            obj.simpleDate = new Date(obj.simpleDate);
          }
          return obj;
        }
        '''

        self.assertTrue(contains_ignore_whitespace(deserializers_ts.contents, expected_code))

    def test_generates_correct_formdata_body(self):
        self.engine.prepare('localhost:8000', [simple_formdata_endpoint])

        files = self.engine.generate()

        api_ts = [file for file in files if file.path.endswith('api.service.ts')][0]

        expected_code = '''
          simple_get_func(body: SimpleFormData): Observable<any> {
            let formData = new FormData();
            formData.append('simpleString', body.simpleString);
            formData.append('simpleFloat', body.simpleFloat);
            return this.http.get(`localhost:8000/test-url`, formData,
                { responseType: 'json' });
          }
        }
        '''

        self.assertTrue(contains_ignore_whitespace(api_ts.contents, expected_code))

    def test_generates_correct_formdata_with_files_body(self):
        self.engine.prepare('localhost:8000', [formdata_with_file_endpoint])
        files = self.engine.generate()

        api_ts = [file for file in files if file.path.endswith('api.service.ts')][0]

        expected_code = '''
          simple_get_func(body: FormDataWithFile): Observable<any> {
            let formData = new FormData();
            formData.append('simpleDecimal', body.simpleDecimal);
            formData.append('simpleFile', body.simpleFile);
            return this.http.get(`localhost:8000/test-url`, formData,
                { responseType: 'json' });
          }
          '''

        self.assertTrue(contains_ignore_whitespace(api_ts.contents, expected_code))

    def test_generates_interface_formdata_with_files(self):
        self.engine.prepare('localhost:8000', [formdata_with_file_endpoint])

        files = self.engine.generate()

        interface_ts = [file for file in files if file.path.endswith('form-data-with-file.ts')][0]

        expected_code = '''
        export interface FormDataWithFile {
          simpleDecimal?: string;
          simpleFile?: File;
        }
        '''

        self.assertTrue(contains_ignore_whitespace(interface_ts.contents, expected_code))

    def test_generates_correct_get_with_params(self):
        self.engine.prepare('localhost:8000', [simple_get_with_params_endpoint])
        files = self.engine.generate()

        api_ts = [file for file in files if file.path.endswith('api.service.ts')][0]

        expected_code = '''
          simple_get_func(param1: number, param2: string, query_param1: string, header1: string): Observable<any> {
            let params = new HttpParams();
            if (query_param1 !== null && query_param1 !== undefined) {
              params = params.set('query-param1', query_param1);
            }
            let headers = new HttpHeaders();
            if (header1 !== null && header1 !== undefined) {
              headers = headers.set('header1', header1);
            }
            return this.http.get(`localhost:8000/test-url/${param1}/${param2}`,
                { responseType: 'json', headers: headers, params: params });
          }
          '''

        self.assertTrue(contains_ignore_whitespace(api_ts.contents, expected_code))
