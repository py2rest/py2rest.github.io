from unittest import TestCase

from py2rest.engines.ts.fetchapi import FetchApiEngine
from py2rest.tests.integration.endpoints import simple_endpoint, simple_formdata_endpoint, formdata_with_file_endpoint, \
    simple_get_with_params_endpoint
from py2rest.tests.integration.util import contains_ignore_whitespace


class FetchGenerationTestCase(TestCase):

    def setUp(self):
        self.engine = FetchApiEngine()

    def test_generates_single_json_get(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])

        files = self.engine.generate()

        api_js = [file for file in files if file.path.endswith('api.js')][0]

        expected_code = '''
        function simple_get_func() {
          var _url = `localhost:8000/test-url`;
          return fetch(_url, {
            method: 'get',
          });
        }
        '''

        self.assertTrue(contains_ignore_whitespace(api_js.contents, expected_code))

    def test_generates_simple_deserializer(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])
        files = self.engine.generate()

        deserializers_js = [file for file in files if file.path.endswith('deserializers.js')][0]

        expected_code = '''
        function deserializeSimpleJsonGet(response_body) {
          var obj = JSON.parse(response_body);
          if (obj.simpleDate) {
            obj.simpleDate = new Date(obj.simpleDate);
          }
          return obj;
        }
        '''

        self.assertTrue(contains_ignore_whitespace(deserializers_js.contents, expected_code))

    def test_generates_correct_formdata_body(self):
        self.engine.prepare('localhost:8000', [simple_formdata_endpoint])

        files = self.engine.generate()

        api_js = [file for file in files if file.path.endswith('api.js')][0]

        expected_code = '''
                        function simple_get_func(body) {
                          var _url = `localhost:8000/test-url`;
                        
                          let formData = new FormData();
                          formData.append('simpleString', body.simpleString);
                          formData.append('simpleFloat', body.simpleFloat);
                        
                          return fetch(_url, {
                            method: 'get',
                            body: formData
                          });
                        }
                        '''

        self.assertTrue(contains_ignore_whitespace(api_js.contents, expected_code))

    def test_generates_correct_formdata_with_files_body(self):
        self.engine.prepare('localhost:8000', [formdata_with_file_endpoint])
        files = self.engine.generate()

        api_js = [file for file in files if file.path.endswith('api.js')][0]

        expected_code = '''
                        function simple_get_func(body) {
                          var _url = `localhost:8000/test-url`;
                        
                          let formData = new FormData();
                          formData.append('simpleDecimal', body.simpleDecimal);
                          formData.append('simpleFile', body.simpleFile);
                        
                          return fetch(_url, {
                            method: 'get',
                            body: formData
                          });
                        }
                        '''

        self.assertTrue(contains_ignore_whitespace(api_js.contents, expected_code))

    def test_generates_correct_get_with_params(self):
        self.engine.prepare('localhost:8000', [simple_get_with_params_endpoint])
        files = self.engine.generate()

        api_js = [file for file in files if file.path.endswith('api.js')][0]

        expected_code = '''
                        function simple_get_func(param1, param2, query_param1, header1) {
                          var _params = new URLSearchParams();
                          if (query_param1 !== null && query_param1 !== undefined) {
                            _params.append('query-param1', query_param1);
                          }
                          var _url = `localhost:8000/test-url/${param1}/${param2}?` + _params.toString();
                          var _headers = {};
                          if (header1 !== null && header1 !== undefined) {
                            _headers['header1'] = header1;
                          }
                          return fetch(_url, {
                            method: 'get',
                            headers: _headers,
                          });
                        }
                        '''

        self.assertTrue(contains_ignore_whitespace(api_js.contents, expected_code))
