from unittest import TestCase


from py2rest.engines.python.py_requests import PythonRequestsEngine
from py2rest.tests.integration.endpoints import simple_endpoint, simple_formdata_endpoint, formdata_with_file_endpoint, \
    simple_get_with_params_endpoint
from py2rest.tests.integration.util import contains_ignore_whitespace


class PythonGenerationTestCase(TestCase):

    def setUp(self):
        self.engine = PythonRequestsEngine()

    def test_generates_single_json_get(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])

        files = self.engine.generate()

        api_py = [file for file in files if file.path.endswith('api.py')][0]

        expected_header = 'def simple_get_func():'
        expected_body = '    return requests.get(\'localhost:8000/test-url\')'

        self.assertIn(expected_header, api_py.contents)
        self.assertIn(expected_body, api_py.contents)

    def test_generates_simple_deserializer(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])
        files = self.engine.generate()

        deserializers_py = [file for file in files if file.path.endswith('deserializers.py')][0]

        expected_code = '''
                        def deserialize_simple_json_get(response_body):
                            obj = json.loads(response_body)
                            if obj.get('simpleDate') is not None:
                                obj['simpleDate'] = dateutil.parser.parse(obj['simpleDate']).date()
                            return obj
                        '''

        self.assertTrue(contains_ignore_whitespace(deserializers_py.contents, expected_code))

    def test_copies_encoder(self):
        self.engine.prepare('localhost:8000', [simple_endpoint])
        files = self.engine.generate()

        py2rest_encoder_py = [file for file in files if file.path.endswith('py2rest_encoder.py')][0]

        self.assertIn('class Py2RestEncoder(json.JSONEncoder):', py2rest_encoder_py.contents)

    def test_generates_correct_formdata_body(self):
        self.engine.prepare('localhost:8000', [simple_formdata_endpoint])

        files = self.engine.generate()

        api_py = [file for file in files if file.path.endswith('api.py')][0]

        expected_header = 'def simple_get_func(body: dict):'
        expected_body = '    _form_data = {' \
                        '        \'simpleString\': body.get(\'simpleString\'),' \
                        '        \'simpleFloat\': body.get(\'simpleFloat\'),' \
                        '    }' \
                        'return requests.get(\'localhost:8000/test-url\', data=_form_data)'

        self.assertIn(expected_header, api_py.contents)
        self.assertTrue(contains_ignore_whitespace(api_py.contents, expected_body))

    def test_generates_correct_formdata_with_files_body(self):
        self.engine.prepare('localhost:8000', [formdata_with_file_endpoint])
        files = self.engine.generate()

        api_py = [file for file in files if file.path.endswith('api.py')][0]

        expected_header = 'def simple_get_func(body: dict):'
        expected_body = '    _form_data = {' \
                        '        \'simpleDecimal\': body.get(\'simpleDecimal\'),' \
                        '    }' \
                        '    _files = {' \
                        '        \'simpleFile\': body.get(\'simpleFile\'),' \
                        '    }' \
                        '    return requests.get(\'localhost:8000/test-url\', data=_form_data, files=_files)'

        self.assertIn(expected_header, api_py.contents)
        self.assertTrue(contains_ignore_whitespace(api_py.contents, expected_body))

    def test_generates_correct_get_with_params(self):
        self.engine.prepare('localhost:8000', [simple_get_with_params_endpoint])
        files = self.engine.generate()

        api_py = [file for file in files if file.path.endswith('api.py')][0]

        expected_header = 'def simple_get_func(param1: int, param2: str, query_param1: str, header1: str):'
        expected_body = '''
            _params = {
                'query-param1': str(query_param1),
            }
            _headers = {
                'header1': str(header1),
            }
            return requests.get('localhost:8000/test-url/{}/{}'.format(param1, param2), params=_params, headers=_headers)
            '''

        self.assertIn(expected_header, api_py.contents)
        self.assertTrue(contains_ignore_whitespace(api_py.contents, expected_body))

