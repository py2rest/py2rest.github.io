import string


def contains_ignore_whitespace(container: str, part: str) -> bool:
    return part.translate(str.maketrans(dict.fromkeys(string.whitespace))) in container.translate(str.maketrans(dict.fromkeys(string.whitespace)))
