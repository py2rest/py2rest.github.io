import os

# Example used for generating code cited in py2rest thesis.

from py2rest import http_method
from py2rest.api.fields import FormData, CharField, FileUploadField, JSONObject, DateField, ListField, DateTimeField
from py2rest.api.parameter import Parameter
from py2rest.api_endpoint import api_endpoint
from py2rest.engines.openapi.openapi import OpenAPIEngine
from py2rest.engines.python.py_requests import PythonRequestsEngine
from py2rest.engines.ts.angular import AngularEngine
from py2rest.engines.ts.fetchapi import FetchApiEngine
from py2rest.py2rest_gen import Py2Rest


class CommentJSON(JSONObject):
    author = CharField()
    content = CharField()
    date = DateTimeField()


class CreateArticleJSON(JSONObject):
    title = CharField()
    description = CharField()
    content = CharField()


class ArticleJSON(JSONObject):
    author = CharField()
    content = CharField()
    publicationDate = DateField()
    comments = ListField(element_type=CommentJSON())
    attachmentUrls = ListField(element_type=CharField())


class AttachmentForm(FormData):
    uploader = CharField()
    attachedFile = FileUploadField()


@api_endpoint(url='/articles/{article_type}/{author}',
              url_params=[Parameter('article_type', int), Parameter('author', str)],
              headers=[Parameter('Authorization', str)],
              method=http_method.POST,
              group_name='api',
              name='createArticle',
              body=CreateArticleJSON(),
              return_type=ArticleJSON())
def create_article():
    pass


@api_endpoint(url='/articles/{article_id}',
              url_params=[Parameter('article_id', int)],
              headers=[Parameter('Authorization', str)],
              method=http_method.PUT,
              group_name='api',
              name='addAttachment',
              body=AttachmentForm(),
              return_type=None)
def addAttachment():
    pass


base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

python_path = os.path.join(base_path, 'gen', 'python')
angular_path = os.path.join(base_path, 'gen', 'angular')
fetch_path = os.path.join(base_path, 'gen', 'fetch')
openapi_path = os.path.join(base_path, 'gen', 'openapi')
py2re = Py2Rest('http://127.0.0.1:8000', [AngularEngine(generation_path=angular_path),
                                          FetchApiEngine(generation_path=fetch_path),
                                          PythonRequestsEngine(generation_path=python_path),
                                          OpenAPIEngine(generation_path=openapi_path)])
py2re.read_decorated_endpoints()
py2re.generate()
